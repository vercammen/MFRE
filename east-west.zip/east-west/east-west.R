rm(list = ls())
pacman::p_load(tidyverse, here, lubridate,tsibble, broom)

# import "cpi_east_west_clean.RDS"
cpi <- readRDS(here("data","cpi_province.RDS"))  
   
# create net cpi
# create dummies for each 5 years beginning in 1997 (1992 - 96 omitted)
# create western dummy (bc,alberta,sask,manitob) and eastern dummy (others != ontario quebec)
# create interactions: early10*west, late10*west, early10*east, late10*east
cpi = cpi %>% mutate(
  net = cpi - cpi_all,
  late90 = ifelse(year >=1997 & year <= 2001,1,0),
  early00 = ifelse(year >=2002 & year <= 2006,1,0),
  late00 = ifelse(year >=2007 & year <= 2011,1,0),
  early10 = ifelse(year >=2012 & year <= 2016,1,0),
  late10 = ifelse(year >=2017 & year <= 2022,1,0),
  west = ifelse(geo=="British Columbia"|geo=="Alberta"|geo=="Saskatchewan"|geo=="Manitoba",1,0),
  east = ifelse(geo=="New Brunswick"|geo=="Nova Scotia"|geo=="Newfoundland and Labrador"|geo=="Prince Edward Island",1,0),
  early10_w = early10*west,
  late10_w = late10*west,
  early10_e = early10*east,
  late10_e = late10*east
  ) 

# create abbreviations for categories
 cat1 <- "Bakery products"
cat2 <- "Dairy products"
cat3 <- "Fish"
cat4 <- "Food"
cat5 <- "Fresh fruit"
cat6 <- "Meat"
cat7 <- "Other food products and non-alcoholic beverages"
cat8 <- "Fresh vegetables"

cpi <- cpi %>%
  filter(item != "All-items") %>%
  mutate(item = replace(item, item == "Bakery products", "cat1"),
         item = replace(item, item == "Dairy products", "cat2"),
         item = replace(item, item == "Fish", "cat3"),
         item = replace(item, item == "Food", "cat4"),
         item = replace(item, item == "Fresh fruit", "cat5"),
         item = replace(item, item == "Meat", "cat6"),
         item = replace(item, item == "Other food products and non-alcoholic beverages", "cat7"),
         item = replace(item, item == "Fresh vegetables", "cat8"))
   
# run regression with subsetted data
 # use tidy function: https://cran.r-project.org/web/packages/broom/vignettes/broom.html

dfcpi = cpi %>% group_by(item) %>%
  do(fitcpi = lm(net~late90+early00+late00+early10+late10+west+east+early10_w+late10_w+early10_e+late10_e, data = .))
results <- lapply(dfcpi$fitcpi, tidy )

# loop through to display the estimation results
for (i in 1:8)
{
  print(i)
  print(eval(parse(text = paste0("cat",i))))
  print(results[[i]])
}

# to graph the regional data we need to widen and then combine provinces into regions 
# choose which category (e.g., "cat4" - Food) to graph
 
category <- "cat4"

# widen  
cpi_wide <- as_tibble(cpi) %>%
  filter(item == category) %>%
  dplyr::select(year_month,geo,net) %>%
  pivot_wider(names_from = geo, values_from = net) %>%
  rename(w1 = "British Columbia",
         w2 = "Alberta",
         w3 = "Saskatchewan",
         w4 = "Manitoba",
         c1 = "Ontario",
         c2 = "Quebec",
         e1 = "New Brunswick",
         e2 = "Nova Scotia",
         e3 = "Prince Edward Island",
         e4 = "Newfoundland and Labrador"
         )

# create regional mean values
cpi_wide <- cpi_wide %>%
  mutate(west = (w1+w2+w3+w4)/4,
         central = (c1+c2)/2,
         east = (e1+e2+e3+e4)/4) %>%
  dplyr::select(year_month,west,central,east)

# graph the results
# create long version of "cpi_wide"
cpi_long <- cpi_wide %>% 
  pivot_longer(!year_month, names_to = "region", values_to = "cpi")

# graph the results 
cpi_long %>%
  ggplot( aes(x=year_month, y=cpi, group=region, color=region)) +
  geom_line()

