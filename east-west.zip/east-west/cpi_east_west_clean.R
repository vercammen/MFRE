rm(list = ls())
pacman::p_load(tidyverse, here, janitor, lubridate, tsibble, gridExtra, urca, forecast, vars)

# read in the raw data

cpi_raw <- read_csv(here("data", "18100004.csv"), show_col_types = FALSE) %>% 
  clean_names() %>%
  mutate(date = ym(ref_date)) %>%
  dplyr::select(date,geo,products_and_product_groups,value) %>%
  rename(item = products_and_product_groups, cpi = value) 

cpi_province <- cpi_raw %>% 
  filter(item ==  "All-items" | 
           item == "Bakery products" |
           item == "Dairy products" |
           item == "Fish" |
           item == "Food" |
           item == "Fresh fruit" |
           item == "Meat" |
           item == "Other food products and non-alcoholic beverages" |
           item == "Fresh vegetables") %>%
  filter(geo ==  "British Columbia" | 
           geo == "Alberta" |
           geo == "Saskatchewan" |
           geo == "Manitoba" |
           geo == "Ontario" |
           geo == "Quebec" |
           geo == "New Brunswick" |
           geo == "Nova Scotia" |
           geo == "Prince Edward Island" |
           geo == "Newfoundland and Labrador") %>% 
  filter(date >= "1992-01-01" & date <= "2022-05-01") %>%
  mutate(year_month = yearmonth(date),
         year = year(date)) %>%
  as_tsibble(key = c(geo,item),index = year_month) %>%
  dplyr::select(-date)

cpi_all <- cpi_province %>%
  filter(item ==  "All-items") %>%
  rename(cpi_all = cpi)  

cpi_province <- left_join(cpi_province,cpi_all[,c("year_month","geo","cpi_all")], by = c("year_month"="year_month","geo"="geo")) %>%
  dplyr::select(year_month,year,geo,item,cpi,cpi_all)

saveRDS(cpi_province,here("data","cpi_province.RDS")) 