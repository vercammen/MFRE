rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, fpp3,tsibble, tsibbledata, fable, gridExtra, urca, forecast, vars)

data <- read.csv(here("data_","co2_data.csv"))

data <- data %>% 
  mutate(Month = yearmonth(date)) %>%
  as_tsibble(index=Month) %>%
  dplyr::select(Month,y,z)
head(data)

# plot the raw data
#data %>% 
#  autoplot(y)

# plot the ACF and PACF
#data %>%
#  ACF(y) %>%
#  autoplot()

#data %>%
#  PACF(y) %>%
#  autoplot()

# plot the first difference of y along with ACF and PACF
#data %>%
#  gg_tsdisplay(difference(y), plot_type='partial')

# plot the 12 month seasonal difference of y along with the 36 month lag ACF and PACF
#data %>%
#  gg_tsdisplay(difference(y,12), plot_type='partial', lag = 36)

# add seasonal first difference and difference of seasonal first difference
data <- data %>% 
  mutate(diff_s = difference(y,12),
         D.diff_s = difference(diff_s)
  )

# estimate: arima(0,1,0), arima(0,0,0)(0,1,0) and arima(0,1,0)(0,1,0) models
#mod1 <- data %>% 
#  model(arima010 = ARIMA(y ~ pdq(0,1,0)),
#      arima000_010 = ARIMA(y ~ pdq(0,0,0) + PDQ(0,1,0)),
#      arima010_010 = ARIMA(y ~ pdq(0,1,0) + PDQ(0,1,0))) 

# display arima(0,1,0) residuals
#mod1 %>%
#  dplyr::select(arima010) %>%
#  gg_tsresiduals() 

# display arima(0,0,0)(0,1,0) residuals
#mod1 %>%
#  dplyr::select(arima000_010) %>%
#  gg_tsresiduals() 

# display arima(0,1,0)(0,1,0) residuals
#mod1 %>%
#  dplyr::select(arima010_010) %>%
#  gg_tsresiduals() 

# estimate the arima(0,1,0)(0,1,0) model with z exogenous variable
mod2 <- data %>% 
  model(exog1 = ARIMA(y ~ 0 + z +  pdq(0,1,0) + PDQ(0,1,0))) %>%
  report()

# show the arima estimates in tidy format and save coefficient as beta
arima_coef <- mod2 %>% tidy()
beta <- arima_coef$estimate 
 
# add the difference of seasonal difference of z to data set
data <- data %>% 
  mutate(diff_zs = difference(z,12),
         D.diff_zs = difference(diff_zs)
  )

# confirm previous results by regressing D.diff_s on D.diff_zs
summary(lm(D.diff_s ~ 0 + D.diff_zs, data = data))

# create 10 forecast values for z equal to z(T) and save as tsibble

future_z <- new_data(data, n = 10) %>%
  mutate(z = last(data$z))

# forecast y using mod2 and future z forecast 
forecast2 <- mod2 %>% 
  forecast(new_data = future_z) 
#%>% 
#  autoplot(data)

# create a manual version of the previous forecast

data2 <- data %>%
  dplyr::select(Month,y,z) %>%
  dplyr::bind_rows(future_z)
   
T <- nrow(data)

 i <- 1

data2[T+i,2] <- data2[T+i-1,2]+data2[T+i-1-11,2]-data2[T+i-1-12,2]+beta*data2[T+i,3]-
  beta*data[T+i-1,3]-beta*data2[T+i-1-11,3]+beta*data[T+i-1-12,3]



# estimate the model using auto-arima
#fit <- data %>%
#  model(ARIMA(y))
#report(fit)

# forecast 30 months ahead
#fit %>% forecast(h=30) %>%
#  autoplot(data) +
#  labs(y = "co2 ppm", title = "co2 Concentration")



#aus_economy <- global_economy %>% 
#  filter(Country == "Australia")
#fit <- aus_economy %>% 
#  model(lm = ARIMA(log(GDP) ~ Population))

#future_aus <- new_data(aus_economy, n = 10) %>% 
#  mutate(Population = last(aus_economy$Population))

#fit %>% 
#  forecast(new_data = future_aus) %>% 
#  autoplot(aus_economy)
 