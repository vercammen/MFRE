rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, fpp3, fredr, tsibble, tsibbledata, fable, gridExtra, urca, forecast, vars)
fredr_set_key("a63c5424469efa8009045b7d02da6a0f")

# import potatoe price

potato <- fredr(
  series_id = "WPU01130603",
  observation_start = as.Date("1992-01-01"),
  observation_end = as.Date("2022-08-01")) %>% 
  rename(ppi = value) %>%
  mutate(month = yearmonth(date)) %>%
  dplyr::select(month,ppi) 
head(potato)

ex_uk <-  fredr(
  series_id = "EXUSUK",
  observation_start = as.Date("1992-01-01"),
  observation_end = as.Date("2022-08-01")) %>% 
  rename(xchng = value) %>%
  mutate(month = yearmonth(date)) %>%
  dplyr::select(month,xchng) 
head(ex_uk)

# merge and create tsibble
ppi <- potato %>% inner_join(ex_uk, by = "month") %>%
   as_tsibble(index=month)
head(ppi)

# add trend and monthly dummies
ppi <- ppi %>% mutate(
  trend = 1:nrow(ex_uk),
  jan = as.integer(month(month) == 1),
  feb = as.integer(month(month) == 2),
  mar = as.integer(month(month) == 3),
  apr = as.integer(month(month) == 4),
  may = as.integer(month(month) == 5),
  jun = as.integer(month(month) == 6),
  jul = as.integer(month(month) == 7),
  aug = as.integer(month(month) == 8),
  sep = as.integer(month(month) == 9),
  oct = as.integer(month(month) == 10),
  nov = as.integer(month(month) == 11))
head(ppi)

# regress ppi on xchng, trend and dummies
ppi_mod <- lm(ppi~xchng+trend+jan+feb+mar+apr+may+jun+jul+aug+sep+oct+nov,data=ppi)
summary(ppi_mod)
