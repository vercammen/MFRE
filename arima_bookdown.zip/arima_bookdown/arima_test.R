rm(list = ls())

pacman::p_load(tidyverse, here, lubridate, fpp3, tsibble, tsibbledata, fable, gridExtra, urca, forecast, vars)

ener <- readRDS(here("data","energy_temp.RDS")) %>%
  mutate(month = yearmonth(month)) %>%
  as_tsibble(index=month)
head(ener)

best <- ener %>% model(arima=ARIMA(energy~0+temp+pdq(4,1,0)+PDQ(0,1,0))) %>%
  residuals()
head(best)

autoplot(as.ts(best$.resid))

acf(best$.resid)  

pacf(best$.resid)  