rm(list = ls())

pacman::p_load(tidyverse, readxl,here, lubridate, tsibble, feasts, gridExtra, fredr, urca, fable, forecast)
 
# import temperature deviation data (12 monthly Excel files)
jan <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Jan", skip = 1, na = "..") %>%
  mutate(Month="01")

feb <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Feb", skip = 1, na = "..") %>%
  mutate(Month="02")

mar <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Mar", skip = 1, na = "..") %>%
  mutate(Month="03")

apr <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Apr", skip = 1, na = "..") %>%
  mutate(Month="04")

may <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "May", skip = 1, na = "..") %>%
  mutate(Month="05")

jun <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Jun", skip = 1, na = "..") %>%
  mutate(Month="06")

jul <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Jul", skip = 1, na = "..") %>%
  mutate(Month="07")

aug <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Aug", skip = 1, na = "..") %>%
  mutate(Month="08")

sep <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Sep", skip = 1, na = "..") %>%
  mutate(Month="09")

oct <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Oct", skip = 1, na = "..") %>%
  mutate(Month="10")

nov <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Nov", skip = 1, na = "..") %>%
  mutate(Month="11")

dec <- read_excel(here("data", "temperature.xlsx"),
                  sheet = "Dec", skip = 1, na = "..") %>%
  mutate(Month="12")

# combine individual months
temp <- rbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec) %>%
  rename(Year=Date) %>%
  mutate(Year=as.numeric(Year),
         Month=as.numeric(Month))
temp2 <-arrange(temp, Year, Month) %>%
  filter(Year>=1973) %>%
  slice(-n())
head(temp2)

# read in energy consumption data
ener_dat <- read.csv(here("data","energy.csv")) %>%
  mutate(month = yearmonth(date)) %>%
  as_tsibble(index = month) %>%
  dplyr::select(month,energy)
head(ener_dat)

# combine data
data <- ener_dat %>%
  mutate(temp = temp2$ClimDiv)

# save data to energy_temp.RDS file
saveRDS(data,here("data","energy_temp.RDS"))

# estimate an arima(0,1,0)(0,1,0)
model_1 <- data %>% 
  model(ARIMA(energy ~ 0 + temp +  pdq(0,1,0) + PDQ(0,1,0))) %>%
  report() 

arima_coef <- model_1 %>% tidy()
arima_coef

# estimate using autoarima
model_2 <- data %>%
  model(ARIMA(energy~temp)) %>%
  report()

auto_coef <- model_2 %>% tidy()
auto_coef

