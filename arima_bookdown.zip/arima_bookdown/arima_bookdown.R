rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, fpp3,tsibble, tsibbledata, fable, gridExtra, urca, forecast, vars)

# open cleaned energy-temperature data
 
data <- readRDS(here("data","energy_temp.RDS"))

# plot the energy use raw data
data %>% 
  autoplot(energy) +
  labs(title = "Monthly U.S. Energy Consumption",
       subtitle = "Residential, Commercial, and Industrial Sectors",
       y = "Energy (trillion BTU)")

# plot the temperture raw data
data %>% 
  autoplot(temp) +
  labs(title = "Monthly U.S. Temperature Deviation",
       subtitle = "Contiguous U.S. Average Temperature Anomaly ",
       y = "Degrees Fahrenheit (F)")

 # add a time trend to the data
data <- data %>%
  mutate(trend = 1:nrow(data))

# regress energy on time trend and monthly dummies
summary(lm(energy~trend+as.factor(month(month)),data=data))
         
# regress temp anomoly on time trend and monthly dummies
summary(lm(temp~trend+as.factor(month(month)),data=data))


# plot the ACF and PACF
data %>%
  ACF(energy) %>%
  autoplot()

data %>%
  PACF(energy) %>%
  autoplot()

# plot the first difference of energy along with ACF and PACF
data %>%
  gg_tsdisplay(difference(energy), plot_type='partial')

# plot the 12 month seasonal difference of energy along with the 36 month lag ACF and PACF
data %>%
  gg_tsdisplay(difference(energy,12), plot_type='partial', lag = 36)

# add seasonal first difference and difference of seasonal first difference
data <- data %>% 
  mutate(diff_s = difference(energy,12),
         D.diff_s = difference(diff_s)
  )

# estimate: arima(0,1,0), arima(0,0,0)(0,1,0) and arima(0,1,0)(0,1,0) models
mod1 <- data %>% 
  model(arima010 = ARIMA(energy ~ pdq(0,1,0)),
      arima000_010 = ARIMA(energy ~ pdq(0,0,0) + PDQ(0,1,0)),
      arima010_010 = ARIMA(energy ~ pdq(0,1,0) + PDQ(0,1,0))) 

# display arima(0,1,0) residuals
mod1 %>%
  dplyr::select(arima010) %>%
  gg_tsresiduals() 

# display arima(0,0,0)(0,1,0) residuals
mod1 %>%
  dplyr::select(arima000_010) %>%
  gg_tsresiduals() 

# display arima(0,1,0)(0,1,0) residuals
mod1 %>%
  dplyr::select(arima010_010) %>%
  gg_tsresiduals() 

# estimate the arima(0,1,0)(0,1,0) model with z exogenous variable
mod2 <- data %>% 
  model(exog1 = ARIMA(energy ~ 0 + temp +  pdq(0,1,0) + PDQ(0,1,0))) %>%
  report()

# show the arima estimates in tidy format and save coefficient as beta
arima_coef <- mod2 %>% tidy()
beta <- arima_coef$estimate 

# add the difference of seasonal difference of temp to data set
data <- data %>% 
  mutate(diff_zs = difference(temp,12),
         D.diff_zs = difference(diff_zs)
  )

# confirm previous results by regressing D.diff_s on D.diff_zs
summary(lm(D.diff_s ~ 0 + D.diff_zs, data = data))

# create 10 forecast values for z equal to z(T) and save as tsibble

future_z <- new_data(data, n = 10) %>%
  mutate(temp = last(data$temp))

# forecast y using mod2 and future z forecast 
forecast2 <- mod2 %>% 
  forecast(new_data = future_z) %>% 
  autoplot(data)

# create a manual version of the previous forecast

data2 <- data %>%
  dplyr::select(month,energy,temp) %>%
  dplyr::bind_rows(future_z)

T <- nrow(data)

i <- 1

data2[T+i,2] <- data2[T+i-1,2]+data2[T+i-1-11,2]-data2[T+i-1-12,2]+beta*data2[T+i,3]-
  beta*data[T+i-1,3]-beta*data2[T+i-1-11,3]+beta*data[T+i-1-12,3]



# estimate the model using auto-arima
fit <- data %>%
  model(ARIMA(temp))
report(fit)

# forecast 30 months ahead
fit %>% forecast(h=30) %>%
  autoplot(data) +
  labs(y = "co2 ppm", title = "co2 Concentration")



#aus_economy <- global_economy %>% 
#  filter(Country == "Australia")
#fit <- aus_economy %>% 
#  model(lm = ARIMA(log(GDP) ~ Population))

#future_aus <- new_data(aus_economy, n = 10) %>% 
#  mutate(Population = last(aus_economy$Population))

#fit %>% 
#  forecast(new_data = future_aus) %>% 
#  autoplot(aus_economy)
