shorten <- function(dfsh, df_for,hist_show){
  N <- nrow(df_for)
  T_begin <- nrow(dfsh)+1
  T_end <- nrow(dfsh)+N
  df_plot <- append_row(dfsh, n = N) %>% 
    mutate(frcst = NA,
           low = NA,
           up = NA)
  df_plot$frcst[T_begin:T_end] <- df_for[,1]  
  df_plot$low[T_begin:T_end] <- df_for[,2]
  df_plot$up[T_begin:T_end] <- df_for[,3]
  
  df_plot <- df_plot %>% 
    filter(row_number() >= (n() - hist_show)) 
  
  return(df_plot)
}