rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, tsibble, gridExtra, urca, forecast, vars)

# import data
noncpidata <- readRDS(here("data","noncpidata.RDS"))
cpidata <- readRDS(here("data","cpidata.RDS"))

# create master data by adding "all_items cpi" to noncpidata
data <- noncpidata %>% 
  left_join(cpidata[,c("year_month","all_items")], data, by="year_month")  

# choose cpi category to forecast (bakery,dairy,fish
# fruit,meat,other,restaurant,other)

category <- "food"

# Identify type ("const" or "trend"), number of lags (p >= 1)
# and presence of seasonality (NULL or 4)

type <- "const"
p <- 2
season = NULL

# identify the number of periods to be forecasted and graphed
N <- 12
n_graph <- 72

# transfer chosen category to master data
# change name of category column to generic name "cat_select"

cat_select <- cpidata[,c("year_month",category)] %>%
  rename(cpi_cat = 2)

data <- data %>% 
  left_join(cat_select, data, by="year_month") 
   

# eliminate high inflation (recent) months if desired
#data <- data %>% 
  #filter_index(~ "2020-12")

# create columns of first differences
# generic name "ct" refers to first difference of chosen category
df <- data %>% mutate(
  ct = difference(cpi_cat),
  al = difference(all_items),
  us = difference(food_us),
  ex = difference(exchange),
  en = difference(energy),
  wa = difference(wages),
  L.ex = lag(ex)) %>%
  dplyr::select(ct,al,us,ex,L.ex,en,wa,trend) %>%
  slice(-c(1:1))

head(df)

# generate ADF testing data

adf_ct <- list(
  trend = ur.df(df$ct, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$ct, type = "drift", selectlags = "AIC")
)

adf_al <- list(
  trend = ur.df(df$al, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$al, type = "drift", selectlags = "AIC")
)

adf_us <- list(
  trend = ur.df(df$us, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$us, type = "drift", selectlags = "AIC") 
) 

adf_ex <- list(
  trend = ur.df(df$ex, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$ex, type = "drift", selectlags = "AIC")
)

adf_en <- list(
  trend = ur.df(df$en, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$en, type = "drift", selectlags = "AIC")
)

adf_wa <- list(
  trend = ur.df(df$wa, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$wa, type = "drift", selectlags = "AIC")
)

# generate specific test statistics

cttrend <- summary(adf_ct$trend)@teststat
ctdrift <- summary(adf_ct$drift)@teststat
ctstat <- cbind(cttrend,ctdrift)

altrend <- summary(adf_al$trend)@teststat
aldrift <- summary(adf_al$drift)@teststat
alstat <- cbind(altrend,aldrift)

ustrend <- summary(adf_us$trend)@teststat
usdrift <- summary(adf_us$drift)@teststat
usstat <- cbind(ustrend,usdrift)

extrend <- summary(adf_ex$trend)@teststat
exdrift <- summary(adf_ex$drift)@teststat
exstat <- cbind(extrend,exdrift)

entrend <- summary(adf_en$trend)@teststat
endrift <- summary(adf_en$drift)@teststat
enstat <- cbind(entrend,endrift)

watrend <- summary(adf_wa$trend)@teststat
wadrift <- summary(adf_wa$drift)@teststat
wastat <- cbind(watrend,wadrift)

adf_cpi <- rbind(ctstat,alstat,usstat,exstat,enstat,wastat)
rownames(adf_cpi)  <- c("CPI All", "CPI Food", "CPI U.S.", "Exchange", "Energy", "Wages")
adf_cpi

# generate ADF critical value using the first variable
rbind(adf_al$trend@cval,adf_al$drift@cval)

# check for significance of time trend
ct_tm <- list(
  ct1 = lm(ct~trend,data=df),
  ct2 = lm(ct~lag(al)+trend,data=df)
)
summary(ct_tm$ct1)$coefficients[,c(1,4)]
summary(ct_tm$ct2)$coefficients[,c(1,4)]

al_tm <- list(
  al1 = lm(al~trend,data=df),
  al2 = lm(al~lag(al)+trend,data=df)
)
summary(al_tm$al1)$coefficients[,c(1,4)]
summary(al_tm$al2)$coefficients[,c(1,4)]
  
us_tm <- list(
  us1 = lm(us~trend,data=df),
  us2 = lm(us~lag(us)+trend,data=df)
)
summary(us_tm$us1)$coefficients[,c(1,4)]
summary(us_tm$us2)$coefficients[,c(1,4)]

ex_tm <- list(
  ex1 = lm(ex~trend,data=df),
  ex2 = lm(ex~lag(ex)+trend,data=df)
)
summary(ex_tm$ex1)$coefficients[,c(1,4)]
summary(ex_tm$ex2)$coefficients[,c(1,4)]

en_tm <- list(
  en1 = lm(en~trend,data=df),
  en2 = lm(en~lag(en)+trend,data=df)
)
summary(en_tm$en1)$coefficients[,c(1,4)]
summary(en_tm$en2)$coefficients[,c(1,4)]

wa_tm <- list(
  wa1 = lm(wa~trend,data=df),
  wa2 = lm(wa~lag(en)+trend,data=df)
)
summary(wa_tm$wa1)$coefficients[,c(1,4)]
summary(wa_tm$wa2)$coefficients[,c(1,4)]

# separate variables into endogenous and exogenous
x <- df %>%
  dplyr::select(ct,us,en,wa)
head(x)
z <- df %>%
  dplyr::select(al,ex,L.ex)

# use VARselect to choose lag structure
lags <-VARselect(x[,1:4],lag.max=12,type=type,exog=z[,1:3],season=season)
lags$selection

# estimate a one period VAR with cpi_all exogenous
var_mod <- VAR(x[,1:4], p = 2, type = type, exogen = z[,c(1,2,3)], season = season)
#var_mod <- VAR(x[,1:4], p = 2, type = "const",exogen = z[,1:3])
coef(var_mod)

# create the forecast for the exogenous variables
al <- rep(0,each=N)
ex <- rep(0,each=N)
L.ex <- rep(0,each=N)

# use the following if period T values should repeat
#al <-rep(as.numeric(df[nrow(df),1]),each=6)
#ex <-rep(as.numeric(df[nrow(df),1]),each=6)
#L.ex <-rep(as.numeric(df[nrow(df),1]),each=6)

exog_for <- as.matrix(cbind(al,ex,L.ex))
 

# forecast the Canadian CPI series
ctcpi_for <- predict(var_mod, n.ahead = N, ci = 0.95, dumvar = exog_for, season = 4)
forecast <-ctcpi_for$fcst$ct[,1:3]
forecast

#plot(foodcpi_for, names=foodcpi_for$fcst$fd)

# add the fitted values to the df data frame (delete top two rows first)
df <- df %>%
  slice(-c(1:2)) %>%
  mutate(fitted = ctcpi_for$model$varresult$ct$fitted.values)
 
# use saved function to create truncated data for plotting
source(here("shorten_function.R"))


df_plot <-shorten(df,forecast,n_graph)

# plot shortened data (historic, fitted, forecasted, prediction intervals)
ggplot() + 
  geom_line(data = df_plot, aes(x = year_month, y = ct), color = "black") +
  geom_line(data = df_plot, aes(x = year_month, y = fitted), color = "red",size=1) +
  geom_line(data = df_plot, aes(x = year_month, y = frcst), color = "blue",size=1.5) +
  geom_line(data = df_plot, aes(x = year_month, y = low), color = "green",size=1.5) +
  geom_line(data = df_plot, aes(x = year_month, y = up), color = "green",size=1.5) +
  labs(y= category, x = "Date") +
  ggtitle("Realized and Forecasted Difference in CPI")

# conversion to levels
# https://stats.stackexchange.com/questions/261102/arima-versus-arma-on-differenced-data-gives-different-prediction-interval/263954#263954

# create new df consisting for cpi_cat in levels and forecasts
T <- nrow(data)

for_level <- data %>%
  dplyr::select(year_month,cpi_cat) %>%  
  append_row(n = nrow(forecast)) %>%
  mutate(fcst_diff = NA,
         low_diff = NA,
         up_diff = NA,
         fcst_lev = NA,
         low_lev = NA,
         up_lev = NA)

for_level[seq(T+1,T+N),"fcst_diff"] <- forecast[,1]
for_level[seq(T+1,T+N),"low_diff"] <- forecast[,2]
for_level[seq(T+1,T+N),"up_diff"] <- forecast[,3]

# loop through to calculate the forecast in levels

for_level[T,"fcst_lev"]=for_level[T,"cpi_cat"]
for_level[T,"low_lev"]=for_level[T,"cpi_cat"]
for_level[T,"up_lev"]=for_level[T,"cpi_cat"]

for (t in 1:N)
{
for_level[T+t,"fcst_lev"] <- for_level[T+t-1,"fcst_lev"] + for_level[T+t,"fcst_diff"]
for_level[T+t,"low_lev"] <- for_level[T+t-1,"low_lev"] + for_level[T+t,"low_diff"]
for_level[T+t,"up_lev"] <- for_level[T+t-1,"up_lev"] + for_level[T+t,"up_diff"]
}

# shorten the df then graph it

for_level <- for_level %>%
  filter(row_number() >= (n() - n_graph)) 

ggplot() + 
  geom_line(data = for_level, aes(x = year_month, y = cpi_cat), color = "black") +
  geom_line(data = for_level, aes(x = year_month, y = fcst_lev), color = "red",size=1.5) +
  geom_line(data = for_level, aes(x = year_month, y = low_lev), color = "blue",size=1.5) +
  geom_line(data = for_level, aes(x = year_month, y = up_lev), color = "blue",size=1.5) +
  labs(y= category, x = "Date") +
  ggtitle("Realized and Forecasted CPI")
