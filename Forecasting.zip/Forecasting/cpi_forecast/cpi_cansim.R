library(cansim)
cpi <- get_cansim('18-10-0004-03')