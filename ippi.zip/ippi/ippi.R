pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast,
        here, janitor, gridExtra, fredr, reshape2)

##### IPPI DATA
# https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810026601

# read in raw ippi data
# ippi_raw <- read_csv(here("data", "18100266.csv"), show_col_types = FALSE) %>% 
#   clean_names() %>%
#   mutate(date = ym(ref_date)) %>%
#   dplyr::select(date,north_american_product_classification_system_napcs,value) %>%
#   rename(item = north_american_product_classification_system_napcs, ippi = value)  
# 
# saveRDS(ippi_raw,here("data","ippi_raw.RDS"))

ippi_raw <- readRDS(here("data","ippi_raw.RDS"))

# filter bread
breadIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Bread, rolls and flatbreads [18313]") %>%
  dplyr::select(date,ippi) %>%
  rename(breadIPPI=ippi) 

# filter cereal
cerealIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Breakfast cereal and other cereal products [18311]") %>%
  dplyr::select(date,ippi) %>%
  rename(cerealIPPI=ippi) 

# filter canola
canolaIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Canola or rapeseed oil (crude, once-refined, fuel-grade or industrial) [182133]") %>%
  dplyr::select(date,ippi) %>%
  rename(canolaIPPI=ippi)

# filter coffee
coffeeIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Coffee and tea [19111]") %>%
  dplyr::select(date,ippi) %>%
  rename(coffeeIPPI=ippi)

# filter cookies
cookiesIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Cookies, crackers and baked sweet goods [18314]") %>%
  dplyr::select(date,ippi) %>%
  rename(cookiesIPPI=ippi)

# filter flour
flourIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Flour and other grain mill products [18212]") %>%
  dplyr::select(date,ippi) %>%
  rename(flourIPPI=ippi) 

# filter flour_mixes
flourMixesIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Flour mixes, dough and dry pasta [18312]") %>%
  dplyr::select(date,ippi) %>%
  rename(flourMixesIPPI=ippi) 

# filter pork
porkIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Fresh and frozen pork [17212]") %>%
  dplyr::select(date,ippi) %>%
  rename(porkIPPI=ippi) 

# filter beef
beefIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Fresh and frozen beef and veal [17211]") %>%
  dplyr::select(date,ippi) %>%
  rename(beefIPPI=ippi) 

# filter ham
hamIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Ham, bacon and other processed pork [172152]") %>%
  dplyr::select(date,ippi) %>%
  rename(hamIPPI=ippi)

# filter margarine
margarineIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Margarine and cooking oils [18211]") %>%
  dplyr::select(date,ippi) %>%
  rename(margarineIPPI=ippi)

# filter soybeans
soybeansIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Soybean oil (crude, once-refined, fuel-grade or industrial) [182132]") %>%
  dplyr::select(date,ippi) %>%
  rename(soybeansIPPI=ippi)

# filter sugar
sugarIPPI <- ippi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(item == "Sugar and sugar mill by-products [18214]") %>%
  dplyr::select(date,ippi) %>%
  rename(sugarIPPI=ippi) 

##### CPI DATA
# https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810000401

# read in cpi data

# cpi_raw <- read_csv(here("data", "18100004.csv"), show_col_types = FALSE) %>% 
#   clean_names() %>%
#   mutate(date = ym(ref_date)) %>%
#   dplyr::select(date,geo,products_and_product_groups,value) %>%
#   rename(item = products_and_product_groups, cpi = value)
# 
# saveRDS(cpi_raw,here("data","cpi_raw.RDS"))

cpi_raw <- readRDS(here("data","cpi_raw.RDS"))

# filter for all-items
allCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "All-items") %>%
  dplyr::select(date,cpi) %>%
  rename(allCPI=cpi) 

# filter for bakery
bakeryCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Bakery products") %>%
  dplyr::select(date,cpi) %>%
  rename(bakeryCPI=cpi) 

# filter for bread
breadCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Bread, rolls and buns") %>%
  dplyr::select(date,cpi) %>%
  rename(breadCPI=cpi)

# filter for cereal
cerealCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Cereal products (excluding baby food)") %>%
  dplyr::select(date,cpi) %>%
  rename(cerealCPI=cpi) 

# filter for cereal
cerealCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Cereal products (excluding baby food)") %>%
  dplyr::select(date,cpi) %>%
  rename(cerealCPI=cpi) 

# filter for coffee
coffeeCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Coffee") %>%
  dplyr::select(date,cpi) %>%
  rename(coffeeCPI=cpi) 

# filter for cookies
cookiesCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Cookies and crackers") %>%
  dplyr::select(date,cpi) %>%
  rename(cookiesCPI=cpi)

# filter for crackers
crackersCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Crackers and crisp breads (2013=100)") %>%
  dplyr::select(date,cpi) %>%
  rename(crackersCPI=cpi) 

# filter for fats
fatsCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Edible fats and oils") %>%
  dplyr::select(date,cpi) %>%
  rename(fatsCPI=cpi)

# filter for flour
flourCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Flour and flour-based mixes") %>%
  dplyr::select(date,cpi) %>%
  rename(flourCPI=cpi)

# filter for beef
beefCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh or frozen beef") %>%
  dplyr::select(date,cpi) %>%
  rename(beefCPI=cpi) 

# filter for pork
porkCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh or frozen pork") %>%
  dplyr::select(date,cpi) %>%
  rename(porkCPI=cpi) 

# filter for ham
hamCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Ham and bacon") %>%
  dplyr::select(date,cpi) %>%
  rename(hamCPI=cpi) 

# filter for Margarine
margarineCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Margarine") %>%
  dplyr::select(date,cpi) %>%
  rename(margarineCPI=cpi)

# filter for pasta
pastaCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Pasta products") %>%
  dplyr::select(date,cpi) %>%
  rename(pastaCPI=cpi) 

# filter for sugar
sugarCPI <- cpi_raw %>% 
  filter(date >= "1980-01-01" & date <= "2023-04-01") %>%
  filter(geo == "Canada") %>%
  filter(item == "Sugar and confectionery") %>%
  dplyr::select(date,cpi) %>%
  rename(sugarCPI=cpi) 

######
# Create IPPI and CPI data pairs

# breadIPPI and breadCPI
bread <- breadCPI %>% inner_join(breadIPPI,by="date") 
data_long <- melt(bread, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# cerealIPPI and cerealCPI
cereal <- cerealCPI %>% inner_join(cerealIPPI,by="date") 
data_long <- melt(cereal, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# cookiesIPPI and cookiesCPI
cookies <- cookiesCPI %>% inner_join(cookiesIPPI,by="date") 
data_long <- melt(cookies, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# cookiesIPPI and crackersCPI
cookies_crackers <- crackersCPI %>% inner_join(cookiesIPPI,by="date") 
data_long <- melt(cookies_crackers, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# flourIPPI and flourCPI
flour <- flourCPI %>% inner_join(flourIPPI,by="date") 
data_long <- melt(flour, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# flourMixesIPPI and bakeryCPI
flourMixes_bakery <- bakeryCPI %>% inner_join(flourMixesIPPI,by="date") 
data_long <- melt(flourMixes_bakery, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# flourMixesIPPI and pastaCPI
flourMixes_pasta <- pastaCPI %>% inner_join(flourMixesIPPI,by="date") 
data_long <- melt(flourMixes_pasta, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# canolaIPPI and fatsCPI
canola_fats <- fatsCPI %>% inner_join(canolaIPPI,by="date") 
data_long <- melt(canola_fats, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# soybeansIPPI and fatsCPI
soybeans_fats <- fatsCPI %>% inner_join(soybeansIPPI,by="date") 
data_long <- melt(soybeans_fats, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# margarineIPPI and margarineCPI
margarine <- margarineCPI %>% inner_join(margarineIPPI,by="date") 
data_long <- melt(margarine, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# coffeeIPPI and coffeeCPI
coffee <- coffeeCPI %>% inner_join(coffeeIPPI,by="date") 
data_long <- melt(coffee, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# sugarIPPI and sugarCPI
sugar <- sugarCPI %>% inner_join(sugarIPPI,by="date") 
data_long <- melt(sugar, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")

# hamIPPI and hamCPI
ham <- hamCPI %>% inner_join(hamIPPI,by="date") 
data_long <- melt(ham, id = "date") %>% rename(index=variable)
ggplot(data_long,aes(x = date,y = value,color = index))+geom_line() + xlab("") + ylab("")
