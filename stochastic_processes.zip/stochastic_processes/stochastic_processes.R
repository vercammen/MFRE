# use https://eodhistoricaldata.com/ for symbol search
# a good reference for dynlm package is http://web.vu.lt/mif/a.buteikis/wp-content/uploads/2020/04/Example_05.html
# https://www.codegrepper.com/code-examples/r/r+exclude+rows 
# http://www.sthda.com/english/articles/39-regression-model-diagnostics/161-linear-regression-assumptions-and-diagnostics-in-r-essentials/

rm(list = ls())
graphics.off()
library(tidyverse)
library(lubridate)
library(tsibble)
library(feasts)
library(broom)
# suppressPackageStartupMessages({library(dynlm)})

# trial API for crude oil: http://eodhistoricaldata.com
api_token <- "OeAFFmMliFG5orCUuwAKQ8l4WWFQ67YX"
symbol <- "CL.COMM"
ticker.link <- paste("http://eodhistoricaldata.com/api/eod/", 
                         symbol,"?from=2017-01-01&to=2021-12-31&period=d", "&api_token=", 
                         api_token)
crude_oil <- read.csv(url(ticker.link))
tail(crude_oil) # last row invalid - delete

# delete last row, convert date and convert tibble to tsibble
crude_oil <- crude_oil[-nrow(crude_oil),] %>% 
  mutate(Date = lubridate::ymd(Date)) %>% 
  as_tsibble(index=Date)

# plot the data
autoplot(crude_oil, Close) +
  labs(title = "Daily Closing Price of WTI Crude Oil Futures",
       subtitle = "Rolling - Next to Expire Contract",
       y = "USD $/barrel")


# create a new tsibble consisting of the average monthly price of WTI crude oil
crude_oil_mth <- crude_oil %>%
  mutate(Year_Month = yearmonth(Date)) %>%
  index_by(Year_Month) %>%
  summarise_all(mean)  

# plot the monthly data
autoplot(crude_oil_mth, Close) +
  labs(title = "Monthly Average Closing Price of WTI Crude Oil Futures",
       subtitle = "Rolling - Next to Expire Contract",
       y = "USD $/barrel")

# create a new tsibble consisting of the weekly average price of WTI crude oil
crude_oil_wk <- crude_oil %>%
  mutate(Year_Week = yearweek(Date)) %>%
  index_by(Year_Week) %>%
  summarise_all(mean)  

autoplot(crude_oil_wk, Close) +
  labs(title = "Monthly Average Closing Price of WTI Crude Oil Futures",
       subtitle = "Rolling - Next to Expire Contract",
       y = "USD $/barrel")


 # use personal api to pull in one year's worth of daily wheat prices
myapi.token <- "62544bc0966f75.26641220"
mysymbol <- "ZW.COMM"
myticker.link <- paste("http://eodhistoricaldata.com/api/eod/", 
                     mysymbol,"?from=2021-01-01&to=2021-12-31&period=d", "&api_token=", 
                     myapi.token)
wheat <- read.csv(url(myticker.link))
head(wheat)

# FRED API: a63c5424469efa8009045b7d02da6a0f
library(fredr)
fredr_set_key("a63c5424469efa8009045b7d02da6a0f")

# U.S. Monthly CPI: https://fred.stlouisfed.org/series/CPIAUCSL

CPI_mnth <- fredr(
     series_id = "CPIAUCSL",
     observation_start = as.Date("1990-01-01"),
     observation_end = as.Date("2021-12-01")
   )

# select columns, rename column and convert to tsibble
CPI_mnth <- CPI_mnth %>% 
  as_tsibble(index=date) %>% 
  select(date, value) %>%
  rename(CPI = value)

# graph data

autoplot(CPI_mnth, CPI) +
  labs(title = "Monthly U.S. CPI: All Urban Consumers",
       subtitle = "Index 1982-1984=100")

# U.S. Monthly Potato PPI: https://fred.stlouisfed.org/series/WPU01130603

PPI_potat <- fredr(
  series_id = "WPU01130603",
  observation_start = as.Date("2000-01-01"),
  observation_end = as.Date("2021-12-01"))

# select columns, rename column and convert to tsibble
PPI_potat <- PPI_potat %>% 
  as_tsibble(index=date) %>% 
  select(date, value) %>%
  rename(PPI = value)

# graph data

autoplot(PPI_potat, PPI) +
  labs(title = "Monthly U.S. PPI for Potatoes",
       subtitle = "Index Dec 1991=100")

# convert potato PPI to quarterly and calculate averages

PPI_qtr <- PPI_potat %>%
  mutate(Year_Qtr = yearquarter(date, fiscal_start = 1)) %>%
  index_by(Year_Qtr) %>%
  summarise_all(mean) %>%
  mutate(Qtr=lubridate::quarter(date)) %>%
  select(Year_Qtr,Qtr,PPI)

# calculate quarterly averages

PPI_qtr_avg <- as_tibble(PPI_qtr) %>%
  group_by(Qtr) %>%
  summarize(mean_PPI = mean(PPI))
PPI_qtr_avg

# calculate the autocorrelation for weekly and monthly crude oil prices
crude_oil_wk %>% ACF(Close) %>% autoplot()
crude_oil_mth %>% ACF(Close) %>% autoplot()

# create a new variable which is log return of the weekly crude oil price
crude_wk <- crude_oil_wk %>% 
  mutate(rtn_crude = difference(log(Close))) %>%
  select(Year_Week,Close,rtn_crude) 
  # %>% slice(-1)

# remove the first row and plot the correlogram
crude_wk[-c(1:1),] %>% ACF(rtn_crude) %>% autoplot()

# testing for autocorrelation: Section 3.3 in https://otexts.com/fpp2/residuals.html
ljung_box(crude_wk[-1,]$rtn_crude, lag = 10, dof = 0)

#Box.test(crude_wk[-1,]$rtn_crude,lag=10, fitdf=0, type="Ljung")

# add to crude_wk three lags of the return variable
crude_wk <- crude_wk %>% mutate(L.rtn_crude = lag(rtn_crude,1),
                                L2.rtn_crude = lag(rtn_crude,2),
                                L3.rtn_crude = lag(rtn_crude,3)) 

# regress rtn_crude on three lags and add residual to crude_wk
modL3 <- lm(rtn_crude ~ L.rtn_crude + L2.rtn_crude + L3.rtn_crude, data = crude_wk[-c(1:3),])
summary(modL3)

# collect residuals, fitted values, etc.
# modL3_post <- augment(modL3) %>% add_row(1:2,.before=1)


# repeat with two lags
modL2 <- lm(rtn_crude ~ L.rtn_crude + L2.rtn_crude, data = crude_wk[-c(1:2),])
summary(modL2)

# add residuals from two lag model to crude_wk
crude_wk <- crude_wk %>% mutate(L2.resid = c(NA, NA, NA, modL2$residuals))

# plot correlogram for residuals
crude_wk[-c(1:3),] %>% ACF(L2.resid) %>% autoplot()

# test residuals for autocorrelation
ljung_box(crude_wk[-4,]$L2.resid, lag = 10, dof = 0)


# plot the correlogram of the residuals
crude_wk1 %>% ACF(crude_res) %>% autoplot() 

# testing for autocorrelation: Section 3.3 in https://otexts.com/fpp2/residuals.html
Box.test(crude_wk1$rtn_crude,lag=10, fitdf=0, type="Lj")
Box.test(crude_wk1$crude_res,lag=10, fitdf=0, type="Lj")

# use two lags and re-test the residuals for autocorrelation
crude_ar2 <- dynlm(rtn_crude ~ lag(rtn_crude,1) + lag(rtn_crude,2),data = crude_wk)
out2 <- summary(crude_ar2)

