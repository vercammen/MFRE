rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, tsibble, gridExtra, urca, forecast, vars)

# import data
data <- readRDS(here("data","cpidata.RDS"))

# eliminate high inflation months (step end of 2020)
data <- data %>%
  filter_index(~ "2020-12")

# pair-wise first difference regressions: realfood cpi with:
 # us food cpi OKAY
#summary(lm(difference(food)~difference(cpi_all)+difference(food_us)+trend-1,data))
# exchange rate OKAY
#summary(lm(difference(food)~difference(cpi_all)+difference(exchange)+trend-1,data))
# energy index OKAY
#summary(lm(difference(food)~difference(cpi_all)+difference(energy)+trend-1,data))
# wages OKAY
#summary(lm(difference(food)~difference(cpi_all)+difference(wages)+trend-1,data))

# create columns of first differences
df <- data %>% mutate(
  al = difference(cpi_all),
  fd = difference(food),
  us = difference(food_us),
  ex = difference(exchange),
  en = difference(energy),
  wa = difference(wages),
  L.ex = lag(ex)) %>%
  dplyr::select(al,fd,us,ex,L.ex,en,wa,trend) %>%
  slice(-c(1:2))

head(df)

# generate ADF testing data

adf_al <- list(
  trend = ur.df(df$al, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$al, type = "drift", selectlags = "AIC")
)

adf_fd <- list(
  trend = ur.df(df$fd, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$fd, type = "drift", selectlags = "AIC")
)

adf_us <- list(
  trend = ur.df(df$us, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$us, type = "drift", selectlags = "AIC") 
) 

adf_ex <- list(
  trend = ur.df(df$ex, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$ex, type = "drift", selectlags = "AIC")
)

adf_en <- list(
  trend = ur.df(df$en, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$en, type = "drift", selectlags = "AIC")
)

adf_wa <- list(
  trend = ur.df(df$wa, type = "trend", selectlags = "AIC"),
  drift = ur.df(df$wa, type = "drift", selectlags = "AIC")
)

# generate specific test statistics

altrend <- summary(adf_al$trend)@teststat
aldrift <- summary(adf_al$drift)@teststat
alstat <- cbind(altrend,aldrift)

fdtrend <- summary(adf_fd$trend)@teststat
fddrift <- summary(adf_fd$drift)@teststat
fdstat <- cbind(fdtrend,fddrift)

ustrend <- summary(adf_us$trend)@teststat
usdrift <- summary(adf_us$drift)@teststat
usstat <- cbind(ustrend,usdrift)

extrend <- summary(adf_ex$trend)@teststat
exdrift <- summary(adf_ex$drift)@teststat
exstat <- cbind(extrend,exdrift)

entrend <- summary(adf_en$trend)@teststat
endrift <- summary(adf_en$drift)@teststat
enstat <- cbind(entrend,endrift)

watrend <- summary(adf_wa$trend)@teststat
wadrift <- summary(adf_wa$drift)@teststat
wastat <- cbind(watrend,wadrift)

adf_cpi <- rbind(alstat,fdstat,usstat,exstat,enstat,wastat)
rownames(adf_cpi)  <- c("CPI All", "CPI Food", "CPI U.S.", "Exchange", "Energy", "Wages")
adf_cpi

# generate ADF critical value using the first variable
rbind(adf_al$trend@cval,adf_al$drift@cval)

# check for signficance of time trend
cpi_reg <- list(
  al1 = lm(al~trend,data=df),
  al2 = lm(al~lag(al)+trend,data=df)
)

summary(cpi_reg$al1)$coefficients[,c(1,4)]

# separate variables into endogenous and exogenous
x <- df %>%
  dplyr::select(fd,us,en,wa)
head(x)
z <- df %>%
  dplyr::select(al,ex,L.ex)
head(z)

# estimate a one period VAR with cpi_all exogenous
#var_mod <- VAR(x[,1:4], p = 2, type = "trend", exogen = z[,c(1,2,3)], season = 4)
var_mod <- VAR(x[,1:4], p = 2, type = "trend",exogen = z[,1:2],season = 4)
coef(var_mod)

# create the forecast for the exogenous variables
al <- c(0,0,0,0,0,0)
ex <- c(0,0,0,0,0,0)
L.ex <- c(0,0,0,0,0,0)
#al <-rep(as.numeric(df[nrow(df),1]),each=6)
#ex <-rep(as.numeric(df[nrow(df),1]),each=6)
#L.ex <-rep(as.numeric(df[nrow(df),1]),each=6)
exog_for <- as.matrix(cbind(al,ex))
#exog_for <- as.matrix(cbind(al,ex,L.ex))

# forecast the Canadian CPI series
#foodcpi_for <- predict(var_mod, n.ahead = 6, ci = 0.95, dumvar = exog_for)
foodcpi_for <- predict(var_mod, n.ahead = 6, ci = 0.95, dumvar = exog_for)

forecast <-foodcpi_for$fcst$fd[,1:3]
forecast
plot(foodcpi_for, names=foodcpi_for$fcst$fd)

# use saved function to create truncated data for plotting
source(here("shorten_function.R"))

df_plot <-shorten(df,forecast,50)

# plot shortened data
ggplot() + 
  geom_line(data = df_plot, aes(x = year_month, y = fd), color = "black") +
  geom_line(data = df_plot, aes(x = year_month, y = frcst), color = "green",size=1.5) +
  geom_line(data = df_plot, aes(x = year_month, y = low), color = "red",size=1.5) +
  geom_line(data = df_plot, aes(x = year_month, y = up), color = "blue",size=1.5) 



