rm(list = ls())
pacman::p_load(tidyverse, here, lubridate, tsibble, gridExtra, urca, forecast, vars)

cad_usd_ex <- readRDS(here("data","cad_usd_ex.RDS"))
cpi_allitems_ts <- readRDS(here("data","cpi_allitems_ts.RDS"))
cpi_food_ts <- readRDS(here("data","cpi_food_ts.RDS"))
energy_index <- readRDS(here("data","energy_index.RDS"))
# gscpi <- readRDS(here("data","gscpi.RDS"))
us_cpi_food <- readRDS(here("data","us_cpi_food.RDS"))
wages_real <- readRDS(here("data","wages_real.RDS"))

# add year_month to each object and filter date to begin Jan of 1997
cpi_allitems_ts <- cpi_allitems_ts %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(cpi_all = cpi.allitems) %>%
  dplyr::select(year_month,cpi_all) %>%
  filter_index("1997-01" ~ .)

cad_usd_ex <- cad_usd_ex %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(exchange = cad.usd.ex) %>%
  dplyr::select(year_month,exchange) %>%
  filter_index("1997-01" ~ .)

cpi_food_ts <- cpi_food_ts %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(food = cpi.food) %>%
  dplyr::select(year_month,food) %>%
  filter_index("1997-01" ~ .)

energy_index <- energy_index %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(energy = energy.index) %>%
  dplyr::select(year_month,energy) %>%
  filter_index("1997-01" ~ .)  

# set May value for energy index equal to April value
energy_index <- append_row(energy_index)
 n <- nrow(energy_index)
 energy_index[n,2] = energy_index[n-1,2]
 
us_cpi_food <- us_cpi_food %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(food_us = us.cpi.food) %>%
  dplyr::select(year_month,food_us) %>%
  filter_index("1997-01" ~ .)

wages_real <- wages_real[-nrow(wages_real),] %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(wages = wages_real) %>%
  dplyr::select(year_month,wages) %>%
  filter_index("1997-01" ~ .) %>%
  filter_index(~ "2022-05")

# combine data and create new column for a time trend

cpidata <- dplyr::bind_cols(cpi_allitems_ts,
                         cad_usd_ex[,-1],
                         cpi_food_ts[,-1],
                         energy_index[,-1],
                         us_cpi_food[,-1],
                         wages_real[,-1]) %>%
  mutate(trend = 1:nrow(wages_real)) %>%
  dplyr:: select(year_month,cpi_all,trend,food,food_us,exchange,energy,wages)

# save the data to a RDS file
saveRDS(cpidata,here("data","cpidata.RDS"))
