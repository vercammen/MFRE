rm(list = ls())
pacman::p_load(tidyverse, here, janitor, lubridate, tsibble, gridExtra, urca, forecast, vars)

# Read in the non Canadian cpi data

cad_usd_ex <- readRDS(here("data","cad_usd_ex.RDS"))
#cpi_allitems_ts <- readRDS(here("data","cpi_allitems_ts.RDS"))
# cpi_food_ts <- readRDS(here("data","cpi_food_ts.RDS"))
energy_index <- readRDS(here("data","energy_index.RDS"))
# gscpi <- readRDS(here("data","gscpi.RDS"))
us_cpi_food <- readRDS(here("data","us_cpi_food.RDS"))
wages_real <- readRDS(here("data","wages_real.RDS"))

# add year_month to each object and filter date to begin Jan of 1997
 
cad_usd_ex <- cad_usd_ex %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(exchange = cad.usd.ex) %>%
  dplyr::select(year_month,exchange) %>%
  filter_index("1997-01" ~ .)
 
energy_index <- energy_index %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(energy = energy.index) %>%
  dplyr::select(year_month,energy) %>%
  filter_index("1997-01" ~ .)  

# set May value for energy index equal to April value
energy_index <- append_row(energy_index)
 n <- nrow(energy_index)
 energy_index[n,2] = energy_index[n-1,2]
 
us_cpi_food <- us_cpi_food %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(food_us = us.cpi.food) %>%
  dplyr::select(year_month,food_us) %>%
  filter_index("1997-01" ~ .)

wages_real <- wages_real[-nrow(wages_real),] %>% 
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  rename(wages = wages_real) %>%
  dplyr::select(year_month,wages) %>%
  filter_index("1997-01" ~ .) %>%
  filter_index(~ "2022-05")

# combine data and create new column for a time trend

noncpidata <- dplyr::bind_cols(cad_usd_ex,
                         energy_index[,-1],
                         us_cpi_food[,-1],
                         wages_real[,-1]) %>%
  mutate(trend = 1:nrow(wages_real)) %>%
  dplyr:: select(year_month,trend,food_us,exchange,energy,wages)

# save the data to a RDS file
# saveRDS(noncpidata,here("data","noncpidata.RDS"))

# import the stats canada cpi data (downloaded as large zip with all categories)
# https://www150.statcan.gc.ca/t1/tbl1/en/cv.action?pid=1810000403

cpi_raw <- read_csv(here("data", "18100004.csv"), show_col_types = FALSE) %>% 
  clean_names() %>%
  mutate(date = ym(ref_date)) %>%
  dplyr::select(date,geo,products_and_product_groups,value) %>%
  rename(item = products_and_product_groups, cpi = value) 

# filter the data and convert to a tsibble
all_items <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "All-items") %>%
  rename(all_items = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,all_items)

bakery <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Bakery products") %>%
  rename(bakery = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,bakery)

dairy <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Dairy products") %>%
  rename(dairy = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,dairy)

fish <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Fish") %>%
  rename(fish = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,fish)

food <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Food") %>%
  rename(food = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,food)

fruit <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Fresh fruit") %>%
  rename(fruit = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,fruit)

meat <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Meat") %>%
  rename(meat = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,meat)

other <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Other food products and non-alcoholic beverages") %>%
  rename(other = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,other)

restaurant <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Food purchased from restaurants") %>%
  rename(restaurant = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,restaurant)

veggies <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1997-01-01" & date <= "2022-05-01") %>%
  filter(item == "Fresh vegetables") %>%
  rename(veggies = cpi) %>%
  mutate(year_month = yearmonth(date)) %>%
  as_tsibble(index = year_month) %>%
  dplyr::select(year_month,veggies)

# combine the cpi data
cpidata <- dplyr::bind_cols(all_items,
                               bakery[,-1],
                               dairy[,-1],
                               fish[,-1],
                               food[,-1],
                               fruit[,-1],
                               meat[,-1],
                               other[,-1],
                               restaurant[,-1],
                               veggies[,-1]) 

saveRDS(cpidata,here("data","cpidata.RDS"))