pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast,
               here, janitor, gridExtra, fredr, reshape2, urca)

# read in the saved pairs and triplets
butter <- readRDS(here("data","butter.RDS"))
flour <- readRDS(here("data","flour.RDS"))
bread <- readRDS(here("data","bread.RDS"))
chicken <- readRDS(here("data","chicken.RDS"))
pork <- readRDS(here("data","pork.RDS"))
fats <- readRDS(here("data","fats.RDS"))

# read in energy and wage series
energy_df <- readRDS(here("data","energy_df.RDS"))
wage_df <- readRDS(here("data","wage_df.RDS"))

# add energy and wage index to triplets
bread <- bread %>% inner_join(energy_df,by="date")
bread <- bread %>% inner_join(wage_df,by="date")

butter <- butter %>% inner_join(energy_df,by="date")
butter <- butter %>% inner_join(wage_df,by="date")
 
chicken <- chicken %>% inner_join(energy_df,by="date")
chicken <- chicken %>% inner_join(wage_df,by="date")
 
fats <- fats %>% inner_join(energy_df,by="date")
fats <- fats %>% inner_join(wage_df,by="date")
 
flour <- flour %>% inner_join(energy_df,by="date")
flour <- flour %>% inner_join(wage_df,by="date")
 
pork <- pork %>% inner_join(energy_df,by="date")
pork <- pork %>% inner_join(wage_df,by="date")

#####
# convert to tsibble and then take first differences
bread <- bread %>%
  as_tsibble(index=date)

D.bread <- bread %>%
  mutate(D.grainFPPI = difference(grainFPPI),
         D.breadIPPI = difference(breadIPPI),
         D.breadCPI = difference(breadCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.grainFPPI,D.breadIPPI,D.breadCPI,D.energy,D.wage) %>%
  slice(-1)

butter <- butter %>%
  as_tsibble(index=date)

D.butter <- butter %>%
  mutate(D.milkFPPI = difference(milkFPPI),
         D.butterIPPI = difference(butterIPPI),
         D.butterCPI = difference(butterCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.milkFPPI,D.butterIPPI,D.butterCPI,D.energy,D.wage)%>%
  slice(-1)

chicken <- chicken %>%
  as_tsibble(index=date)

D.chicken <- chicken %>%
  mutate(D.chickenFPPI = difference(chickenFPPI),
         D.chickenIPPI = difference(chickenIPPI),
         D.chickenCPI = difference(chickenCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.chickenFPPI,D.chickenIPPI,D.chickenCPI,D.energy,D.wage) %>%
  slice(-1)

chicken <- chicken %>%
  as_tsibble(index=date)

D.fats <- fats %>%
  mutate(D.oilseedsFPPI = difference(oilseedsFPPI),
         D.canolaIPPI = difference(canolaIPPI),
         D.fatsCPI = difference(fatsCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.oilseedsFPPI,D.canolaIPPI,D.fatsCPI,D.energy,D.wage) %>%
  slice(-1)


flour <- flour %>%
  as_tsibble(index=date)

D.flour <- flour %>%
  mutate(D.grainFPPI = difference(grainFPPI),
         D.flourIPPI = difference(flourIPPI),
         D.flourCPI = difference(flourCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.grainFPPI,D.flourIPPI,D.flourCPI,D.energy,D.wage) %>%
  slice(-1)

pork <- pork %>%
  as_tsibble(index=date)

D.pork <- pork %>%
  mutate(D.hogsFPPI = difference(hogsFPPI),
         D.porkIPPI = difference(porkIPPI),
         D.porkCPI = difference(porkCPI),
         D.energy = difference(energy),
         D.wage=difference(wage)) %>%
  dplyr::select(date,D.hogsFPPI,D.porkIPPI,D.porkCPI,D.energy,D.wage) %>%
  slice(-1)

# if quarterly dummies are used the must be added manually to exogenous variables
D.bread <- D.bread %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

D.butter <- D.butter %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

D.chicken <- D.chicken %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

D.fats <- D.fats %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

D.flour <- D.flour %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

D.pork <- D.pork %>%
  mutate(period = month(date),
         qtr1 = ifelse(period == 1| period == 2| period == 3, 1,0),
         qtr2 = ifelse(period == 4| period == 5| period == 6, 1,0),
         qtr3 = ifelse(period == 7| period == 8| period == 9, 1,0)
  ) %>%
  dplyr::select(-period)

####
# create exogenous variables without and with quarterly dummies
x_bread <- D.bread[,5:6]
x_butter <- D.butter[,5:6]
x_chicken <- D.chicken[,5:6]
x_fats <- D.fats[,5:6]
x_flour <- D.flour[,5:6]
x_pork <- D.pork[,5:6]

x4_bread <- D.bread[,5:9]
x4_butter <- D.butter[,5:9]
x4_chicken <- D.chicken[,5:9]
x4_fats <- D.fats[,5:9]
x4_flour <- D.flour[,5:9]
x4_pork <- D.pork[,5:9]
