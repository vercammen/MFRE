# IMPORTANT butterCPI does not construct properly when the full program is
# run. It is necessary to highlight the two blocks (lines 321-326, 533-534)
# for the butter db to construct properly.

pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast,
               here, janitor, gridExtra, fredr, reshape2)

# set start and end date for filter
start_date <- "1997-01-01" # start date for wage
end_date <- "2023-03-01"

# read in the wage and energy data
wage_df <- read_csv(here("raw_data","wageindex.csv"),show_col_types = FALSE) %>%
  clean_names() %>%
        mutate(date = my(date)) %>%
        filter(date >= start_date & date <= end_date) %>%
        dplyr::select(date,goods_producing_sector_7) %>%
       rename(wage = goods_producing_sector_7)

saveRDS(wage_df,here("data","wage_df.RDS"))
 
energy_df <- read_csv(here("raw_data","energyindex.csv"),show_col_types = FALSE) %>%
  clean_names() %>%
        mutate(date = my(date)) %>%
        filter(date >= start_date & date <= end_date) %>%
        dplyr::select(date,m_ener) %>%
       rename(energy = m_ener)

saveRDS(energy_df,here("data","energy_df.RDS"))

 

##### FPPI Data (Version 32100098)
# Farm product price index (FPPI), monthly
# https://www150.statcan.gc.ca/n1/en/catalogue/32100098
# fppi_raw <- read_csv(here("raw_data", "32100098.csv"), show_col_types = FALSE) %>%
#      clean_names() %>%
#      mutate(date = ym(ref_date)) %>%
#      dplyr::select(date,geo,commodity_groups,value) %>%
#     rename(item = commodity_groups, fppi = value)

#saveRDS(fppi_raw,here("data","fppi_raw.RDS"))
fppi_raw <- readRDS(here("data","fppi_raw.RDS"))

###### FPPI Data (Version 32100077)
# Farm product prices, crops and livestock
# https://www150.statcan.gc.ca/n1/en/catalogue/32100077
# farm_raw <- read_csv(here("raw_data", "32100077.csv"), show_col_types = FALSE) %>% 
#      clean_names() %>%
#      mutate(date = ym(ref_date)) %>%
#      dplyr::select(date,geo,farm_products,uom,value) %>%
#     rename(item = farm_products, price = value) 
 
# saveRDS(farm_raw,here("data","farm_raw.RDS"))

farm_raw <- readRDS(here("data","farm_raw.RDS"))


##### IPPI DATA
# https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810026601

# read in raw ippi data
# ippi_raw <- read_csv(here("raw_data", "18100266.csv"), show_col_types = FALSE) %>% 
#   clean_names() %>%
#   mutate(date = ym(ref_date)) %>%
#   dplyr::select(date,north_american_product_classification_system_napcs,value) %>%
#   rename(item = north_american_product_classification_system_napcs, ippi = value)  
 
# saveRDS(ippi_raw,here("data","ippi_raw.RDS"))

ippi_raw <- readRDS(here("data","ippi_raw.RDS"))

##### CPI DATA
# https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810000401

# read in cpi data
# cpi_raw <- read_csv(here("raw_data", "18100004.csv"), show_col_types = FALSE) %>% 
#   clean_names() %>%
#   mutate(date = ym(ref_date)) %>%
#   dplyr::select(date,geo,products_and_product_groups,value) %>%
#   rename(item = products_and_product_groups, cpi = value)
 
# saveRDS(cpi_raw,here("data","cpi_raw.RDS"))

cpi_raw <- readRDS(here("data","cpi_raw.RDS"))

######
#### Filter FPPI for select categories

# filter grain
grainFPPI <- fppi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Grains [A11]") %>%
  filter(geo == "Canada") %>%
  dplyr::select(date,fppi) %>%
  rename(grainFPPI=fppi) 

# filter hogs
hogsFPPI <- fppi_raw %>% 
  filter(date >= "1981-01-01" & date <= end_date) %>%
  filter(item == "Hogs [A22]") %>%
  filter(geo == "Canada") %>%
  dplyr::select(date,fppi) %>%
  rename(hogsFPPI=fppi) 

# filter oilseeds
oilseedsFPPI <- fppi_raw %>% 
  filter(date >= "1981-01-01" & date <= end_date) %>%
  filter(item == "Oilseeds [A12]") %>%
  filter(geo == "Canada") %>%
  dplyr::select(date,fppi) %>%
  rename(oilseedsFPPI=fppi) 

# filter milk
milkFPPI <- fppi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Unprocessed milk [A25]") %>%
  filter(geo == "Canada") %>%
  dplyr::select(date,fppi) %>%
  rename(milkFPPI=fppi) 

# filter chicken
chickenFPPI <- fppi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Chickens, turkeys, chicks, poults [A23]") %>%
  filter(geo == "Canada") %>%
  dplyr::select(date,fppi) %>%
  rename(chickenFPPI=fppi) 

######
#### Filter Farm Price for select categories

# filter for canola
canolaPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Saskatchewan") %>%
  filter(item == "Canola (including rapeseed) [113111]") %>%
  dplyr::select(date,uom,price) %>%
  rename(canolaPrice=price) 

# filter for cattle
cattlePrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Alberta") %>%
  filter(item == "Cattle for slaughter [11111111]") %>%
  dplyr::select(date,uom,price) %>%
  rename(cattlePrice=price)

# filter for chicken
chickenPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Quebec") %>%
  filter(item == "Chickens for meat [11113131]") %>%
  dplyr::select(date,uom,price) %>%
  rename(chickenPrice=price)

# filter for eggs
eggPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Saskatchewan") %>%
  filter(item == "Eggs in shell [116111]") %>%
  dplyr::select(date,uom,price) %>%
  rename(eggPrice=price) 

# filter for potatoes
potatoPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Ontario") %>%
  filter(item == "Fresh potatoes for table consumption [114211111]") %>%
  dplyr::select(date,uom,price) %>%
  rename(potatoPrice=price) 

# filter for hogs
hogPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Quebec") %>%
  filter(item == "Hogs [111121]") %>%
  dplyr::select(date,uom,price) %>%
  rename(hogPrice=price) 

# filter for soybeans
soyPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Saskatchewan") %>%
  filter(item == "Soybeans [1151211]") %>%
  dplyr::select(date,uom,price) %>%
  rename(soyPrice=price)

# filter for milk
milkPrice <- farm_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Quebec") %>%
  filter(item == "Unprocessed milk from bovine [11612111]") %>%
  dplyr::select(date,uom,price) %>%
  rename(milkPrice=price) 


########
# filter IPPI data for select categories

# filter bread
breadIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Bread, rolls and flatbreads [18313]") %>%
  dplyr::select(date,ippi) %>%
  rename(breadIPPI=ippi) 

# filter cereal
cerealIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Breakfast cereal and other cereal products [18311]") %>%
  dplyr::select(date,ippi) %>%
  rename(cerealIPPI=ippi) 

# filter canola
canolaIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Canola or rapeseed oil (crude, once-refined, fuel-grade or industrial) [182133]") %>%
  dplyr::select(date,ippi) %>%
  rename(canolaIPPI=ippi)

# filter coffee
coffeeIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Coffee and tea [19111]") %>%
  dplyr::select(date,ippi) %>%
  rename(coffeeIPPI=ippi)

# filter cookies
cookiesIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Cookies, crackers and baked sweet goods [18314]") %>%
  dplyr::select(date,ippi) %>%
  rename(cookiesIPPI=ippi)

# filter flour
flourIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= "2023-08-01") %>%
  filter(item == "Flour and other grain mill products [18212]") %>%
  dplyr::select(date,ippi) %>%
  rename(flourIPPI=ippi) 

# filter flour_mixes
flourMixesIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Flour mixes, dough and dry pasta [18312]") %>%
  dplyr::select(date,ippi) %>%
  rename(flourMixesIPPI=ippi) 

# filter pork
porkIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Fresh and frozen pork [17212]") %>%
  dplyr::select(date,ippi) %>%
  rename(porkIPPI=ippi) 

# filter beef
beefIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Fresh and frozen beef and veal [17211]") %>%
  dplyr::select(date,ippi) %>%
  rename(beefIPPI=ippi) 

# filter ham
hamIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Ham, bacon and other processed pork [172152]") %>%
  dplyr::select(date,ippi) %>%
  rename(hamIPPI=ippi)

# filter margarine
margarineIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Margarine and cooking oils [18211]") %>%
  dplyr::select(date,ippi) %>%
  rename(margarineIPPI=ippi)

# filter soybeans
soybeansIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Soybean oil (crude, once-refined, fuel-grade or industrial) [182132]") %>%
  dplyr::select(date,ippi) %>%
  rename(soybeansIPPI=ippi)

# filter sugar
sugarIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Sugar and sugar mill by-products [18214]") %>%
  dplyr::select(date,ippi) %>%
  rename(sugarIPPI=ippi) 

# filter butter
butterIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Butter, and dry and canned dairy products [17312]") %>%
  dplyr::select(date,ippi) %>%
  rename(butterIPPI=ippi) 

# filter cheese
cheeseIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Cheese and cheese products [17313]") %>%
  dplyr::select(date,ippi) %>%
  rename(cheeseIPPI=ippi) 

# filter chicken
chickenIPPI <- ippi_raw %>% 
  filter(date >= "1981-01-01" & date <= end_date) %>%
  filter(item == "Fresh and frozen chicken [172131]") %>%
  dplyr::select(date,ippi) %>%
  rename(chickenIPPI=ippi) 

# filter iceCream
iceCreamIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Ice cream, sherbet and similar frozen desserts [17314]") %>%
  dplyr::select(date,ippi) %>%
  rename(iceCreamIPPI=ippi)

# filter juice
juiceIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Frozen, fresh and canned fruit and vegetable juices [19211]") %>%
  dplyr::select(date,ippi) %>%
  rename(juiceIPPI=ippi) 

# filter meat
meatIPPI <- ippi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(item == "Meat products [172]") %>%
  dplyr::select(date,ippi) %>%
  rename(meatIPPI=ippi) 



##### CPI DATA

# filter for all-items
allCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "All-items") %>%
  dplyr::select(date,cpi) %>%
  rename(allCPI=cpi) 

# filter for butter
butterCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Butter") %>%
  dplyr::select(date,cpi) %>%
  rename(butterCPI=cpi) 

# filter for bakery
bakeryCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Bakery products") %>%
  dplyr::select(date,cpi) %>%
  rename(bakeryCPI=cpi) 

# filter for bread
breadCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Bread, rolls and buns") %>%
  dplyr::select(date,cpi) %>%
  rename(breadCPI=cpi)

# filter for cereal
cerealCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Cereal products (excluding baby food)") %>%
  dplyr::select(date,cpi) %>%
  rename(cerealCPI=cpi) 

# filter for cereal
cerealCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Cereal products (excluding baby food)") %>%
  dplyr::select(date,cpi) %>%
  rename(cerealCPI=cpi) 

# filter for coffee
coffeeCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Coffee") %>%
  dplyr::select(date,cpi) %>%
  rename(coffeeCPI=cpi) 

# filter for cookies
cookiesCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Cookies and crackers") %>%
  dplyr::select(date,cpi) %>%
  rename(cookiesCPI=cpi)

# filter for crackers
crackersCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Crackers and crisp breads (2013=100)") %>%
  dplyr::select(date,cpi) %>%
  rename(crackersCPI=cpi) 

# filter for fats
fatsCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Edible fats and oils") %>%
  dplyr::select(date,cpi) %>%
  rename(fatsCPI=cpi)

# filter for flour
flourCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Flour and flour-based mixes") %>%
  dplyr::select(date,cpi) %>%
  rename(flourCPI=cpi)

# filter for beef
beefCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh or frozen beef") %>%
  dplyr::select(date,cpi) %>%
  rename(beefCPI=cpi) 

# filter for pork
porkCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh or frozen pork") %>%
  dplyr::select(date,cpi) %>%
  rename(porkCPI=cpi) 

# filter for ham
hamCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Ham and bacon") %>%
  dplyr::select(date,cpi) %>%
  rename(hamCPI=cpi) 

# filter for chicken
chickenCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh or frozen chicken") %>%
  dplyr::select(date,cpi) %>%
  rename(chickenCPI=cpi)

# filter for Margarine
margarineCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Margarine") %>%
  dplyr::select(date,cpi) %>%
  rename(margarineCPI=cpi)

# filter for pasta
pastaCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Pasta products") %>%
  dplyr::select(date,cpi) %>%
  rename(pastaCPI=cpi) 

# filter for sugar
sugarCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Sugar and confectionery") %>%
  dplyr::select(date,cpi) %>%
  rename(sugarCPI=cpi) 

# filter for apples
applesCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Apples") %>%
  dplyr::select(date,cpi) %>%
  rename(applesCPI=cpi) 

# filter for eggs
eggsCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Eggs") %>%
  dplyr::select(date,cpi) %>%
  rename(eggsCPI=cpi)

# filter for milk
milkCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Fresh milk") %>%
  dplyr::select(date,cpi) %>%
  rename(milkCPI=cpi) 

# filter for juice
juiceCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Fruit juices") %>%
  dplyr::select(date,cpi) %>%
  rename(juiceCPI=cpi) 

# filter for iceCream
iceCreamCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Ice cream and related products") %>%
  dplyr::select(date,cpi) %>%
  rename(iceCreamCPI=cpi) 

# filter for lettuce
lettuceCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Lettuce") %>%
  dplyr::select(date,cpi) %>%
  rename(lettuceCPI=cpi) 

# filter for potatoes
potatoesCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Potatoes") %>%
  dplyr::select(date,cpi) %>%
  rename(potatoesCPI=cpi)

# filter for tomatoes
tomatoesCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Tomatoes") %>%
  dplyr::select(date,cpi) %>%
  rename(tomatoesCPI=cpi)

# filter for tomatoes
butterCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Buter") %>%
  dplyr::select(date,cpi) %>%
  rename(butterCPI=cpi) 


######
# Create IPPI and CPI data pairs

# milkFPPI, butterIPPI and butterCPI
butter <- butterIPPI %>% inner_join(milkFPPI,by="date")
butter <- butter %>% inner_join(butterCPI,by="date")

# grainFPPI, flourIPPI and flourCPI
flour <- flourIPPI %>% inner_join(grainFPPI,by="date")
flour <- flour %>% inner_join(flourCPI,by="date")

# grainFPPI, breadIPPI and breadCPI
bread <- breadIPPI %>% inner_join(grainFPPI,by="date")
bread <- bread %>% inner_join(breadCPI,by="date")

# chickenFPPI, chickenIPPI and chickenCPI
chicken <- chickenIPPI %>% inner_join(chickenFPPI,by="date")
chicken <- chicken %>% inner_join(chickenCPI,by="date")

# hogsFPPI, porkIPPI and porkCPI
pork <- porkIPPI %>% inner_join(hogsFPPI,by="date")
pork <- pork %>% inner_join(porkCPI,by="date")

# oilseedsFPPI, canolaIPPI and fatsCPI
fats <- canolaIPPI %>% inner_join(oilseedsFPPI,by="date")
fats <- fats %>% inner_join(fatsCPI,by="date")

####
# save pairs/triplets data
saveRDS(butter,here("data","butter.RDS"))
saveRDS(flour,here("data","flour.RDS"))
saveRDS(bread,here("data","bread.RDS"))
saveRDS(chicken,here("data","chicken.RDS"))
saveRDS(pork,here("data","pork.RDS"))
saveRDS(fats,here("data","fats.RDS"))

### Forecast wage back in time before 2010 using U.S. wage
