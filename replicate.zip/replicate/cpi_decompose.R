# IMPORTANT butterCPI does not construct properly when the full program is
# run. It is necessary to highlight the two blocks (lines 321-326, 533-534)
# for the butter db to construct properly.

pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast,
               here, janitor, gridExtra, fredr, reshape2)

# set start and end date for filter
start_date <- "1997-01-01" # start date for wage
end_date <- "2023-08-01"

 
##### CPI DATA
# https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810000401

# read in cpi data
 cpi_raw <- read_csv(here("raw_data", "18100004.csv"), show_col_types = FALSE) %>% 
   clean_names() %>%
   mutate(date = ym(ref_date)) %>%
   dplyr::select(date,geo,products_and_product_groups,value) %>%
   rename(item = products_and_product_groups, cpi = value)
 
# saveRDS(cpi_raw,here("data","cpi_raw.RDS"))

#cpi_raw <- readRDS(here("data","cpi_raw.RDS"))

 
##### CPI DATA

# filter for all-items
allCPI <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "All-items") %>%
  dplyr::select(date,cpi) %>%
  rename(allCPI=cpi) 

# filter for food
food <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Food") %>%
  dplyr::select(date,cpi) %>%
  rename(food=cpi) 

# filter for shelter
shelter <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Shelter") %>%
  dplyr::select(date,cpi) %>%
  rename(shelter=cpi) 

# filter for household
household <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Household operations, furnishings and equipment") %>%
  dplyr::select(date,cpi) %>%
  rename(household=cpi)

# filter for clothing
clothing <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Clothing and footwear") %>%
  dplyr::select(date,cpi) %>%
  rename(clothing=cpi) 

# filter for ransportation
transportation <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Transportation") %>%
  dplyr::select(date,cpi) %>%
  rename(transportation=cpi) 

# filter for health
health <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Health and personal care") %>%
  dplyr::select(date,cpi) %>%
  rename(health=cpi) 

# filter for recreation
recreation <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Recreation, education and reading") %>%
  dplyr::select(date,cpi) %>%
  rename(recreation=cpi)

# filter for alcohol
alcohol <- cpi_raw %>% 
  filter(date >= start_date & date <= end_date) %>%
  filter(geo == "Canada") %>%
  filter(item == "Alcoholic beverages, tobacco products and recreational cannabis") %>%
  dplyr::select(date,cpi) %>%
  rename(alcohol=cpi) 

 ## Join categories
cpi_data <- food %>% inner_join(shelter, by = "date")
cpi_data <- cpi_data %>% inner_join(household, by = "date")
cpi_data <- cpi_data %>% inner_join(clothing, by = "date")
cpi_data <- cpi_data %>% inner_join(transportation, by = "date")
cpi_data <- cpi_data %>% inner_join(health, by = "date")
cpi_data <- cpi_data %>% inner_join(recreation, by = "date")
cpi_data <- cpi_data %>% inner_join(alcohol, by = "date")
cpi_data <- cpi_data %>% inner_join(allCPI, by = "date")

# saveRDS(cpi_data,here("data","cpi_decompose.RDS"))

inflation <- cpi_data %>%
  mutate(foodINF = log(food)-log(lag(food)),
         shelterINF = log(shelter)-log(lag(shelter)),
         householdINF = log(household)-log(lag(household)),
         clothingINF = log(clothing)-log(lag(clothing)),
         transportationINF = log(transportation)-log(lag(transportation)),
         healthINF = log(health)-log(lag(health)),
         recreationINF = log(recreation)-log(lag(recreation)),
         alcoholINF = log(alcohol)-log(lag(alcohol)),)

cpi_weight <- cpi_data %>%
  mutate(foodWT = 0.1613*food,
         shelterWT = 0.2822*shelter,
         householdWT = 0.1457*household,
         clothingWT = 0.0477*clothing,
         transportationWT = 0.1694*transportation,
         healthWT = 0.0492*health,
         recreationWT = 0.0998*recreation,
         alcoholWT = 0.0447*alcohol,
         cpiWT=foodWT+shelterWT+householdWT+clothingWT+transportationWT+healthWT+recreationWT+alcoholWT,
         check = allCPI-cpiWT)

inflation_weight <- inflation %>%
  mutate(foodWT = 0.1613*foodINF*food/allCPI,
         shelterWT = 0.2822*shelterINF*shelter/allCPI,
         householdWT = 0.1457*householdINF*household/allCPI,
         clothingWT = 0.0477*clothingINF*clothing/allCPI,
         transportationWT = 0.1694*transportationINF*transportation/allCPI,
         healthWT = 0.0492*healthINF*health/allCPI,
         recreationWT = 0.0998*recreationINF*recreation/allCPI,
         alcoholWT = 0.0447*alcoholINF*alcohol/allCPI,
         cpiWT=foodWT+shelterWT+householdWT+clothingWT+transportationWT+healthWT+recreationWT+alcoholWT) %>%
  slice(-1) %>%
  dplyr::select(date,clothingWT,healthWT,alcoholWT,recreationWT,householdWT,foodWT,transportationWT,shelterWT)

# smoothed inflation
library(zoo)

inflation_MA <- inflation_weight %>%
  mutate(foodMA = zoo::rollmean(foodWT, k = 4, fill = NA),
         shelterMA = zoo::rollmean(shelterWT, k = 4, fill = NA),
         householdMA = zoo::rollmean(householdWT, k = 4, fill = NA),
         clothingMA = zoo::rollmean(clothingWT, k = 4, fill = NA),
         transportationMA = zoo::rollmean(transportationWT, k = 4, fill = NA),
         healthMA = zoo::rollmean(healthWT, k = 4, fill = NA),
         recreationMA = zoo::rollmean(recreationWT, k = 4, fill = NA),
         alcoholMA = zoo::rollmean(alcoholWT, k = 4, fill = NA)) %>%
  slice(-1) %>%
  dplyr::select(date,clothingMA,healthMA,alcoholMA,recreationMA,householdMA,foodMA,transportationMA,shelterMA)

#foodMA = zoo::rollmean(inflation_weight$foodWT, k = 3, fill = NA)

# write.csv(inflation_MA,here("data","inflation_MA.csv"))

# create quarterly inflation (sum monthly)

inflation_weight <- inflation_weight %>%
  mutate(quart = yearquarter(date))

inflation_weight <- as_tibble(inflation_weight)

inflation_qtr <- inflation_weight %>% 
  group_by(quart) %>% 
  summarise(clothing = sum(clothingWT),
            health = sum(healthWT),
            alcohol = sum(alcoholWT),
            recreation = sum(recreationWT),
            household = sum(householdWT),
            food = sum(foodWT),
            transportation = sum(transportationWT),
            shelter = sum(shelterWT))

write.csv(inflation_qtr,here("data","inflation_qtr.csv"))
