pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast,
               here, janitor, gridExtra, fredr, reshape2, urca)

# read in the saved pairs and triplets
butter <- readRDS(here("data","butter.RDS"))
flour <- readRDS(here("data","flour.RDS"))
bread <- readRDS(here("data","bread.RDS"))
chicken <- readRDS(here("data","chicken.RDS"))
pork <- readRDS(here("data","pork.RDS"))
fats <- readRDS(here("data","fats.RDS"))

# read in energy and wage series
energy_df <- readRDS(here("data","energy_df.RDS"))
wage_df <- readRDS(here("data","wage_df.RDS"))

##### ADF tests
# test energy and wages for stationarity
adf_energy <- list(
  trend = ur.df(energy_df$energy, type = "trend", selectlags = "AIC"),
  drift = ur.df(energy_df$energy, type = "drift", selectlags = "AIC")
)

adf_wage <- list(
  trend = ur.df(wage_df$wage, type = "trend", selectlags = "AIC"),
  drift = ur.df(wage_df$wage, type = "drift", selectlags = "AIC")
)
  
energy_trend <- summary(adf_energy$trend)@teststat
energy_drift <- summary(adf_energy$drift)@teststat
adf_energy_stat <- cbind(energy_trend,energy_drift)

wage_trend <- summary(adf_wage$trend)@teststat
wage_drift <- summary(adf_wage$drift)@teststat
adf_wage_stat <- cbind(wage_trend,wage_drift)
 
adf_energy_wage <- rbind(adf_energy_stat,adf_wage_stat)
rownames(adf_energy_wage)  <- c("Energy", "Wage")
adf_energy_wage

rbind(adf_energy$trend@cval,adf_energy$drift@cval)


# test three series in butter for stationarity
adf_butter_FPPI <- list(
  trend = ur.df(butter$milkFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(butter$milkFPPI, type = "drift", selectlags = "AIC")
)

adf_butter_IPPI <- list(
  trend = ur.df(butter$butterIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(butter$butterIPPI, type = "drift", selectlags = "AIC")
)

adf_butter_CPI <- list(
  trend = ur.df(butter$butterCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(butter$butterCPI, type = "drift", selectlags = "AIC") 
) 

butter_FPPI_trend <- summary(adf_butter_FPPI$trend)@teststat
butter_FPPI_drift <- summary(adf_butter_FPPI$drift)@teststat
adf_butter_FPPI_stat <- cbind(butter_FPPI_trend,butter_FPPI_drift)

butter_IPPI_trend <- summary(adf_butter_IPPI$trend)@teststat
butter_IPPI_drift <- summary(adf_butter_IPPI$drift)@teststat
adf_butter_IPPI_stat <- cbind(butter_IPPI_trend,butter_IPPI_drift)

butter_CPI_trend <- summary(adf_butter_CPI$trend)@teststat
butter_CPI_drift <- summary(adf_butter_CPI$drift)@teststat
adf_butter_CPI_stat <- cbind(butter_CPI_trend,butter_CPI_drift)

adf_butter <- rbind(adf_butter_FPPI_stat,adf_butter_IPPI_stat,adf_butter_CPI_stat)
rownames(adf_butter)  <- c("Butter_FPPI", "Butter_IPPI", "Butter_CPI")
adf_butter

rbind(adf_butter_FPPI$trend@cval,adf_butter_FPPI$drift@cval)

# energy is stationary at 10 percent
# wage is stationary

# test three series in flour for stationarity
adf_flour_FPPI <- list(
  trend = ur.df(flour$grainFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(flour$grainFPPI, type = "drift", selectlags = "AIC")
)

adf_flour_IPPI <- list(
  trend = ur.df(flour$flourIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(flour$flourIPPI, type = "drift", selectlags = "AIC")
)

adf_flour_CPI <- list(
  trend = ur.df(flour$flourCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(flour$flourCPI, type = "drift", selectlags = "AIC") 
) 

flour_FPPI_trend <- summary(adf_flour_FPPI$trend)@teststat
flour_FPPI_drift <- summary(adf_flour_FPPI$drift)@teststat
adf_flour_FPPI_stat <- cbind(flour_FPPI_trend,flour_FPPI_drift)

flour_IPPI_trend <- summary(adf_flour_IPPI$trend)@teststat
flour_IPPI_drift <- summary(adf_flour_IPPI$drift)@teststat
adf_flour_IPPI_stat <- cbind(flour_IPPI_trend,flour_IPPI_drift)

flour_CPI_trend <- summary(adf_flour_CPI$trend)@teststat
flour_CPI_drift <- summary(adf_flour_CPI$drift)@teststat
adf_flour_CPI_stat <- cbind(flour_CPI_trend,flour_CPI_drift)

adf_flour <- rbind(adf_flour_FPPI_stat,adf_flour_IPPI_stat,adf_flour_CPI_stat)
rownames(adf_flour)  <- c("flour_FPPI", "flour_IPPI", "flour_CPI")
adf_flour

rbind(adf_flour_FPPI$trend@cval,adf_flour_FPPI$drift@cval)

# test three series in bread for stationarity
adf_bread_FPPI <- list(
  trend = ur.df(bread$grainFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(bread$grainFPPI, type = "drift", selectlags = "AIC")
)

adf_bread_IPPI <- list(
  trend = ur.df(bread$breadIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(bread$breadIPPI, type = "drift", selectlags = "AIC")
)

adf_bread_CPI <- list(
  trend = ur.df(bread$breadCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(bread$breadCPI, type = "drift", selectlags = "AIC") 
) 

bread_FPPI_trend <- summary(adf_bread_FPPI$trend)@teststat
bread_FPPI_drift <- summary(adf_bread_FPPI$drift)@teststat
adf_bread_FPPI_stat <- cbind(bread_FPPI_trend,bread_FPPI_drift)

bread_IPPI_trend <- summary(adf_bread_IPPI$trend)@teststat
bread_IPPI_drift <- summary(adf_bread_IPPI$drift)@teststat
adf_bread_IPPI_stat <- cbind(bread_IPPI_trend,bread_IPPI_drift)

bread_CPI_trend <- summary(adf_bread_CPI$trend)@teststat
bread_CPI_drift <- summary(adf_bread_CPI$drift)@teststat
adf_bread_CPI_stat <- cbind(bread_CPI_trend,bread_CPI_drift)

adf_bread <- rbind(adf_bread_FPPI_stat,adf_bread_IPPI_stat,adf_bread_CPI_stat)
rownames(adf_bread)  <- c("bread_FPPI", "bread_IPPI", "bread_CPI")
adf_bread

rbind(adf_bread_FPPI$trend@cval,adf_bread_FPPI$drift@cval)

# test three series in chicken for stationarity
adf_chicken_FPPI <- list(
  trend = ur.df(chicken$chickenFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(chicken$chickenFPPI, type = "drift", selectlags = "AIC")
)

adf_chicken_IPPI <- list(
  trend = ur.df(chicken$chickenIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(chicken$chickenIPPI, type = "drift", selectlags = "AIC")
)

adf_chicken_CPI <- list(
  trend = ur.df(chicken$chickenCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(chicken$chickenCPI, type = "drift", selectlags = "AIC") 
) 

chicken_FPPI_trend <- summary(adf_chicken_FPPI$trend)@teststat
chicken_FPPI_drift <- summary(adf_chicken_FPPI$drift)@teststat
adf_chicken_FPPI_stat <- cbind(chicken_FPPI_trend,chicken_FPPI_drift)

chicken_IPPI_trend <- summary(adf_chicken_IPPI$trend)@teststat
chicken_IPPI_drift <- summary(adf_chicken_IPPI$drift)@teststat
adf_chicken_IPPI_stat <- cbind(chicken_IPPI_trend,chicken_IPPI_drift)

chicken_CPI_trend <- summary(adf_chicken_CPI$trend)@teststat
chicken_CPI_drift <- summary(adf_chicken_CPI$drift)@teststat
adf_chicken_CPI_stat <- cbind(chicken_CPI_trend,chicken_CPI_drift)

adf_chicken <- rbind(adf_chicken_FPPI_stat,adf_chicken_IPPI_stat,adf_chicken_CPI_stat)
rownames(adf_chicken)  <- c("chicken_FPPI", "chicken_IPPI", "chicken_CPI")
adf_chicken

rbind(adf_chicken_FPPI$trend@cval,adf_chicken_FPPI$drift@cval)

# test three series in pork for stationarity
adf_pork_FPPI <- list(
  trend = ur.df(pork$hogsFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(pork$hogsFPPI, type = "drift", selectlags = "AIC")
)

adf_pork_IPPI <- list(
  trend = ur.df(pork$porkIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(pork$porkIPPI, type = "drift", selectlags = "AIC")
)

adf_pork_CPI <- list(
  trend = ur.df(pork$porkCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(pork$porkCPI, type = "drift", selectlags = "AIC") 
) 

pork_FPPI_trend <- summary(adf_pork_FPPI$trend)@teststat
pork_FPPI_drift <- summary(adf_pork_FPPI$drift)@teststat
adf_pork_FPPI_stat <- cbind(pork_FPPI_trend,pork_FPPI_drift)

pork_IPPI_trend <- summary(adf_pork_IPPI$trend)@teststat
pork_IPPI_drift <- summary(adf_pork_IPPI$drift)@teststat
adf_pork_IPPI_stat <- cbind(pork_IPPI_trend,pork_IPPI_drift)

pork_CPI_trend <- summary(adf_pork_CPI$trend)@teststat
pork_CPI_drift <- summary(adf_pork_CPI$drift)@teststat
adf_pork_CPI_stat <- cbind(pork_CPI_trend,pork_CPI_drift)

adf_pork <- rbind(adf_pork_FPPI_stat,adf_pork_IPPI_stat,adf_pork_CPI_stat)
rownames(adf_pork)  <- c("pork_FPPI", "pork_IPPI", "pork_CPI")
adf_pork

rbind(adf_pork_FPPI$trend@cval,adf_pork_FPPI$drift@cval)

# test three series in fats for stationarity
adf_fats_FPPI <- list(
  trend = ur.df(fats$oilseedsFPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(fats$oilseedsFPPI, type = "drift", selectlags = "AIC")
)

adf_fats_IPPI <- list(
  trend = ur.df(fats$canolaIPPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(fats$canolaIPPI, type = "drift", selectlags = "AIC")
)

adf_fats_CPI <- list(
  trend = ur.df(fats$fatsCPI, type = "trend", selectlags = "AIC"),
  drift = ur.df(fats$fatsCPI, type = "drift", selectlags = "AIC") 
) 

fats_FPPI_trend <- summary(adf_fats_FPPI$trend)@teststat
fats_FPPI_drift <- summary(adf_fats_FPPI$drift)@teststat
adf_fats_FPPI_stat <- cbind(fats_FPPI_trend,fats_FPPI_drift)

fats_IPPI_trend <- summary(adf_fats_IPPI$trend)@teststat
fats_IPPI_drift <- summary(adf_fats_IPPI$drift)@teststat
adf_fats_IPPI_stat <- cbind(fats_IPPI_trend,fats_IPPI_drift)

fats_CPI_trend <- summary(adf_fats_CPI$trend)@teststat
fats_CPI_drift <- summary(adf_fats_CPI$drift)@teststat
adf_fats_CPI_stat <- cbind(fats_CPI_trend,fats_CPI_drift)

adf_fats <- rbind(adf_fats_FPPI_stat,adf_fats_IPPI_stat,adf_fats_CPI_stat)
rownames(adf_fats)  <- c("fats_FPPI", "fats_IPPI", "fats_CPI")
adf_fats

rbind(adf_fats_FPPI$trend@cval,adf_fats_FPPI$drift@cval)