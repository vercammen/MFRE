# https://www.r-econometrics.com/timeseries/svarintro/
# https://cran.r-project.org/web/packages/vars/vars.pdf
# https://stats.stackexchange.com/questions/191851/var-forecasting-methodology
# conflict with feats package
rm(list = ls())
#dev.off(dev.list()["RStudioGD"]) 

pacman::p_load(tidyverse, here, tsibble, vars, gridExtra, forecast)

## From BLOG
# Seed the random number generator
set.seed(35)

n <- 250 # Number of observations

# Coefficient matrix
Phi <- matrix(c(0.9, .025,
                0.2, 0.8), 2, byrow=TRUE) 

# check eigenvalues for stability
eigen(Phi)

# Structural coefficients
B <- matrix(c(0.5, 0,
              0.25, 0.3), 2,byrow=TRUE)
 
# generate initial values for X_t
initial <- c(8,5)

# generate n + 1 values for X_t with initial and rest zeros
raw <- cbind(initial, matrix(0, 2, n ))
 
# generate values for X using Phi and B matrices and stndard normal error terms
for (i in 2:(n + 1)){
  raw[, i] <- Phi %*% raw[, i - 1] +  B %*% rnorm(2, 0, 1) 
}

# transpose raw and convert to a data frame
X <- data.frame(t(raw)) %>% mutate(month = 1:nrow(t(raw)))
rownames(X) <- NULL


# convert to a tsibble object
X <- as_tsibble(X,index=month)

par(mar=c(1, 1, 1, 1))
ggplot() + 
  geom_line(data = X, aes(x = month, y = X1), color = "blue") +
  geom_line(data = X, aes(x = month, y = X2), color = "red") +
  ggtitle("Simulated Historical Prices for x1 and x2")

# Estimate reduced form VAR and show standard estimation results
var_est <- vars::VAR(X[,1:2], p = 1, type = "none")
coef(var_est)
#plot(var_est)

# check for stability
#roots(var_est)

# save matrix of coefficients
var_coef <- Bcoef(var_est)

# save variance/covariance matrix for reduced form residuals 
summary(var_est)$covres

# show VAR summary
summary(var_est)

# diagnostic testing



# use last two values of X1 and X2 as starting values for the forecast
X_T <- as.vector(unlist(c(X[nrow(X),1],X[nrow(X),2])))

# recursively generate forecast
Xf1 <- var_coef %*% X_T
Xf2 <- var_coef %*% Xf1
Xf3 <- var_coef %*% Xf2
Xf4 <- var_coef %*% Xf3
Xf <- t(cbind(Xf1,Xf2,Xf3,Xf4))
Xf

# Assign the forecast period
N <- 20
T_begin <- nrow(X)+1
T_end <- nrow(X)+N
 
# forecast
X_for <- predict(var_est, n.ahead = N, ci = 0.95, dumvar = NULL)
# forecasted values for X1 and X2
X1_for <- X_for$fcst$X1[,1:3] 
X2_for <- X_for$fcst$X2[,1:3]  

# plot the pair of forecasts using the plot function
#plot(X_for)

# extend the X tsibble object by the forecast period and add lower and upper prediction intervals
X_plot <- X %>% add_row(month = c(T_begin:T_end)) %>%
  mutate(x1fcst = NA, x2fcst = NA, x1low = NA, x1up = NA, x2low = NA, x2up = NA)

# add forecasted values to X_plot and restrict tsibble to last 50 months
X_plot$x1fcst[T_begin:T_end] <- X1_for[,1]
X_plot$x2fcst[T_begin:T_end] <- X2_for[,1]
X_plot$x1low[T_begin:T_end] <- X1_for[,2]
X_plot$x2low[T_begin:T_end] <- X2_for[,2]
X_plot$x1up[T_begin:T_end] <- X1_for[,3]
X_plot$x2up[T_begin:T_end] <- X2_for[,3]

# plot the last 50 months of historical data and forecasts
x1_plot <- X_plot %>% 
  filter(row_number() >= (n() - 50)) %>%
  dplyr::select(month,X1,x1fcst,x1low,x1up)

x2_plot <- X_plot %>% 
  filter(row_number() >= (n() - 50)) %>%
  dplyr::select(month,X2,x2fcst,x2low,x2up)
 
ggplot() + 
  geom_line(data = x1_plot, aes(x = month, y = X1), color = "black") +
  geom_line(data = x1_plot, aes(x = month, y = x1fcst), color = "green",size=1.5) +
  geom_line(data = x1_plot, aes(x = month, y = x1low), color = "red",size=1.5) +
  geom_line(data = x1_plot, aes(x = month, y = x1up), color = "blue",size=1.5)

ggplot() + 
  geom_line(data = x2_plot, aes(x = month, y = X2), color = "black") +
  geom_line(data = x2_plot, aes(x = month, y = x2fcst), color = "green",size=1.5) +
  geom_line(data = x2_plot, aes(x = month, y = x2low), color = "red",size=1.5) +
  geom_line(data = x2_plot, aes(x = month, y = x2up), color = "blue",size=1.5)

# Analysis of price premium data
# https://stats.stackexchange.com/questions/346497/time-series-seasonality-test
# https://nyhackr.blob.core.windows.net/presentations/Tidy-Your-Time-Series-Analysis-with-Tsibble_Earo-Wang.pdf
rm(list = ls())

# read in data from RDS file and filter out the top two rows to eliminate NA
# rename Month column to date
wood <- readRDS(here("data","wood.RDS")) %>%
  slice(-c(1:2)) %>%
  rename(date = Month)

# add a numerical month indicator column
wood <- wood %>% 
  mutate(month = as.numeric(format(date, "%m")))

# create a quarterly dummy
wood <- wood %>%
  mutate(qtr1 = ifelse(month == 1| month == 2| month == 3, 1,0),
         qtr2 = ifelse(month == 4| month == 5| month == 6, 1,0),
         qtr3 = ifelse(month == 7| month == 8| month == 9, 1,0)
         )

 

# regress each premium variable on quarterly dummy
summary(lm(premW~qtr1+qtr2+qtr3,data=wood))
summary(lm(premE~qtr1+qtr2+qtr3,data=wood))

# create a matrix with the exogenous weather variables
weather <- as.matrix(wood[,4:6])

# create a matrix with quarterly dummies
dummies <- as.matrix(wood[,8:10])

# use VARselect to determine lag structure  
VARselect(wood[,2:3],lag.max=10,type="const",exog=weather,season=4) 

# estimate VAR with quarterly dummies created by R
var1 <- VAR(wood[,2:3], p = 3, type = "const", season = 4)
coef(var1)

# estimate VAR with quarterly dummies supply exogenously
var2 <- VAR(wood[,2:3], p = 3, type = "const", exogen = dummies)
coef(var2)

# create exogenous variables for forecasting
temp <- c(0,0,0,0,0)
L.temp <- c(0,0,0,0,0)
L2.temp <- c(0,0,0,0,0)
temp_for <- as.matrix(cbind(temp,L.temp,L2.temp))

# generate n = 5 month forecast
prem_for1 <- predict(var1, n.ahead = 5, ci = 0.95, dumvar = temp_for)
premW_for1 <- prem_for1$fcst$premW[,1:3] 
premE_for1 <- prem_for1$fcst$premE[,1:3] 

# repeat but now use quarterly dummies and no weather data

# estimate VAR
var2 <- VAR(wood[,2:3], p = 3, type = "const", season = 4)
coef(var2)

# create exogenous variables for forecasting
sd1 <- c(0,0,0,0,0)
sd2 <- c(0,0,0,0,0) 
sd3 <- c(0,0,0,0,0)
seas_for <- as.matrix(cbind(sd1,sd2,sd3))
 
# generate n = 5 month forecast
prem_for2 <- predict(var2, n.ahead = 5, ci = 0.95, dumvar = seas_for)
premW_for2 <- prem_for2$fcst$premW[,1:3] 
premE_for2 <- prem_for2$fcst$premE[,1:3]

# generate forecast with quarterly dummies and only the temp variable
weather2 <- as.matrix(wood[,4])
 
# estimate VAR
var3 <- VAR(wood[,2:3], p = 3, type = "const", season = 4, exogen = weather2)
coef(var3)

# create exogenous variables for forecasting
sd1 <- c(0,0,0,0,0)
sd2 <- c(1,1,0,0,0) 
sd3 <- c(0,0,1,1,1)
temp <- c(0.1,0.2,0.3,0.4,0.5)
exog_var2 <- as.matrix(cbind(sd1,sd2,sd3,temp))

# generate n = 5 month forecast
prem_for3 <- predict(var3, n.ahead = 5, ci = 0.95, dumvar = exog_var2)
premW_for3 <- prem_for3$fcst$premW[,1:3] 
premE_for3 <- prem_for3$fcst$premE[,1:3]

