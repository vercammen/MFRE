rm(list = ls())

pacman::p_load(tidyverse, readxl,here, lubridate, tsibble, feasts, gridExtra, fredr, urca, forecast)
fredr_set_key("a63c5424469efa8009045b7d02da6a0f")

# import crude oil prices from FRED
crude_day <- fredr(
  series_id = "DCOILWTICO",
  observation_start = as.Date("1986-01-01"),
  observation_end = as.Date("2022-04-01")) %>% 
  dplyr::select(date,value) %>% 
  rename(crude_day = value)

# import chip prices from FRED
chips <- fredr(
  series_id = "PCU3211133211135",
  observation_start = as.Date("1986-01-01"),
  observation_end = as.Date("2022-04-01")) %>% 
  dplyr::select(date,value) %>% 
  rename(chips_lev = value)

# import plywood prices from FRED
plywood <- fredr(
  series_id = "WPU083",
  observation_start = as.Date("1986-01-01"),
  observation_end = as.Date("2022-04-01")) %>% 
  dplyr::select(date,value) %>% 
  rename(plywood_lev = value)

# import natural gas prices from FRED
gas <- fredr(
  series_id = "MHHNGSP",
  observation_start = as.Date("1997-01-01"),
  observation_end = as.Date("2022-04-01")) %>% 
  dplyr::select(date,value) %>% 
  rename(gas_lev = value)

# import heating prices from FRED
heat <- fredr(
  series_id = "WPU05730201",
  observation_start = as.Date("1986-01-01"),
  observation_end = as.Date("2022-04-01")) %>% 
  dplyr::select(date,value) %>% 
  rename(heat_lev = value)

# convert daily crude prices to tsibble and then monthly
crude_day <- crude_day[complete.cases(crude_day),] 
crude <- crude_day %>%
   mutate(date = yearmonth(date)) %>%
  group_by(date) %>% 
  summarise(crude_lev = mean(crude_day)) %>%
  as_tsibble(index=date)

# create complete tsibble
wood <- crude %>% 
  mutate(chips_lev = chips$chips_lev) %>%
  mutate(plywood_lev = plywood$plywood_lev) %>%
  mutate(heat_lev = heat$heat_lev)

# add log transformations to the wood tsibble
wood <- wood %>%
  mutate(crude=log(crude_lev),
         chips=log(chips_lev),
         plywood=log(plywood_lev),
         heat=log(heat_lev)) %>%
  dplyr::select(date,crude,heat,chips,plywood)

# create premium variables
wood <- wood %>% 
  mutate(premE=heat-crude,
        premW=plywood-chips) %>%
  dplyr::select(date,premE,premW)

# create second wood tsibble with log of gas added
#wood2 <- wood %>% filter_index("1997-01" ~ .) %>%
#  mutate(gas = log(gas$gas_lev)) 

# add month variables
wood <- wood %>% 
  mutate(month = as.numeric(format(date, "%m")))
 
# import temperature deviation data (12 monthly Excel files)
jan <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Jan", skip = 1, na = "..") %>%
  mutate(Month="01")

feb <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Feb", skip = 1, na = "..") %>%
  mutate(Month="02")

mar <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Mar", skip = 1, na = "..") %>%
  mutate(Month="03")

apr <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Apr", skip = 1, na = "..") %>%
  mutate(Month="04")

may <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "May", skip = 1, na = "..") %>%
  mutate(Month="05")

jun <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Jun", skip = 1, na = "..") %>%
  mutate(Month="06")

jul <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Jul", skip = 1, na = "..") %>%
  mutate(Month="07")

aug <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Aug", skip = 1, na = "..") %>%
  mutate(Month="08")

sep <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Sep", skip = 1, na = "..") %>%
  mutate(Month="09")

oct <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Oct", skip = 1, na = "..") %>%
  mutate(Month="10")

nov <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Nov", skip = 1, na = "..") %>%
  mutate(Month="11")

dec <- read_excel(here("data/raw_data", "temperature.xlsx"),
                  sheet = "Dec", skip = 1, na = "..") %>%
  mutate(Month="12")
  
# combine individual months
temp <- rbind(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec) %>%
  rename(Year=Date) %>%
  mutate(Year=as.numeric(Year),
         Month=as.numeric(Month))
temp2 <-arrange(temp, Year, Month) %>%
  filter(Year>=1986) %>%
  slice(-n())

# add temp2 data to wood tsibble
wood <- wood %>% 
  mutate(temp=temp2$ClimDiv)

# add temperature lags
wood <- wood %>%
  mutate(L.temp=lag(temp),
         L2.temp=lag(temp,2))
  
#saveRDS(wood,here("data","wood.RDS"))