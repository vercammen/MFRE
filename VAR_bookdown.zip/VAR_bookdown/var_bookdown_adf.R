rm(list = ls())

pacman::p_load(tidyverse, here, lubridate, tsibble, vars, feasts, gridExtra, fredr, urca, forecast)

# read data from wood.RDS
wood <- readRDS(here("data","wood.RDS")) %>%
  slice(-c(1:2))

# generate ADF test statistic for premW 
adf_W <- list(
  trend = ur.df(wood$premW, type = "trend", selectlags = "AIC"),
  drift = ur.df(wood$premW, type = "drift", selectlags = "AIC")
)

W_trend <- summary(adf_W$trend)@teststat
W_drift <- summary(adf_W$drift)@teststat
adf_W_test <- cbind(W_trend,W_drift)

# generate ADF test statistic for premE 
adf_E <- list(
  trend = ur.df(wood$premE, type = "trend", selectlags = "AIC"),
  drift = ur.df(wood$premE, type = "drift", selectlags = "AIC")
)

E_trend <- summary(adf_E$trend)@teststat
E_drift <- summary(adf_E$drift)@teststat
adf_E_test <- cbind(E_trend,E_drift)

# group ADF test statistics together

adf_wood <- rbind(adf_W_test,adf_E_test)
rownames(adf_wood)  <- c("PremW", "PremE")
adf_wood

# generate the ADF critical values
rbind(adf_W$trend@cval,adf_W$drift@cval)

# add first differences of three variables to wood tsibble and add a time trend
wood2 <- wood %>%
  mutate(D.premW=difference(premW),
         D.premE=difference(premE)) %>%
  slice(-1) %>%
  dplyr::select(Month,D.premW,D.premE)

# conclude that differenced prices are stationary.
# check if time trend is significant
wood2 <- wood2 %>%
  mutate(Trend=1:nrow(wood2))
summary(lm(D.premW~Trend+lag(D.premW,1)+lag(D.premW,2),data=wood2))
summary(lm(D.premE~Trend+lag(D.premE,1)+lag(D.premE,2),data=wood2))

# determine optimal lags for VAR(2) and VAR(3), assuming no constant or trend (based on previous results)

VARselect(wood[,2:3], lag.max=8,
          type="none")[["selection"]]

# https://www.r-econometrics.com/timeseries/varintro/

woodVAR <- VAR(wood[,2:3],p=3,type="none", exogen = wood[,4:6])
summary(woodVAR)
  
