rm(list = ls())

pacman::p_load(tidyverse, here, lubridate, tsibble, vars, feasts, gridExtra, fredr, urca, forecast)

# read data from wood.RDS
wood <- readRDS(here("data","wood.RDS"))

# generate ADF test statistic for crude oil 
adf_crude <- list(
  trend = ur.df(wood$crude, type = "trend", selectlags = "AIC"),
  drift = ur.df(wood$crude, type = "drift", selectlags = "AIC")
)

crude_trend <- summary(adf_crude$trend)@teststat
crude_drift <- summary(adf_crude$drift)@teststat
adf1 <- cbind(crude_trend,crude_drift)

# generate ADF test statistic for chips 
adf_chips <- list(
  trend = ur.df(wood$chips, type = "trend", selectlags = "AIC"),
  drift = ur.df(wood$chips, type = "drift", selectlags = "AIC")
)

chips_trend <- summary(adf_chips$trend)@teststat
chips_drift <- summary(adf_chips$drift)@teststat
adf2 <- cbind(chips_trend,chips_drift)

# generate ADF test statistic for plywood 
adf_plywood <- list(
  trend = ur.df(wood$plywood, type = "trend", selectlags = "AIC"),
  drift = ur.df(wood$plywood, type = "drift", selectlags = "AIC")
)

plywood_trend <- summary(adf_plywood$trend)@teststat
plywood_drift <- summary(adf_plywood$drift)@teststat
adf3 <- cbind(plywood_trend,plywood_drift)

# group ADF test statistics together

adf_wood <- rbind(adf1,adf2,adf3)
rownames(adf_wood)  <- c("Crude", "Chips", "Plywood")
adf_wood

# generate the ADF critical values
rbind(adf_crude$trend@cval,adf_crude$drift@cval)

# determine optimal lags for VAR(2) and VAR(3)

VARselect(wood[,3:4], lag.max=8,
          type="const")[["selection"]]

VARselect(wood[,3:4], lag.max=8,
          type="trend")[["selection"]]

VARselect(wood[,3:4], lag.max=8,
          type="none")[["selection"]]
  
