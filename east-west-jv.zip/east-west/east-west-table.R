rm(list = ls())
pacman::p_load(tidyverse, here, lubridate,tsibble, broom,stringi)

# import "cpi_east_west_clean.RDS"
cpi <- readRDS(here("data","cpi_province1992.RDS"))  

cpi <- cpi %>%
  mutate(item = recode(item,
                       "All-items" = "all",
                       "Bakery and cereal products (excluding baby food)" = "bake",
                       "Dairy products and eggs" = "dairy",
                       "Fish, seafood and other marine products" = "fish",
                       "Food" = "food",
                       "Fruit, fruit preparations and nuts" = "fruit",
                       "Other food products and non-alcoholic beverages" = "other",
                       "Vegetables and vegetable preparations" = "veggies"
  ))

# create real cpi column  
cpi <- cpi %>%
  mutate(cpiR = cpi/cpiA*100)

# add 5 year time windows
cpi <- cpi %>% mutate(
  window = case_when(year(year_month)>=1992 & year(year_month) <=1996   ~ "a90early", 
                         year(year_month)>=1997 & year(year_month) <=2001 ~ "b90late",
                         year(year_month)>=2002 & year(year_month) <=2006 ~ "c00early",
                         year(year_month)>=2007 & year(year_month) <=2011 ~ "d00late",
                         year(year_month)>=2012 & year(year_month) <=2016 ~ "e10early",
                         TRUE ~ "f10late"))

# group data and calculate group means

cpi_avg <- as_tibble(cpi) %>% group_by(geo,item,window) %>%
  summarise(avg_cpi = mean(cpi),
            avg_cpiA = mean(cpiA),
            avg_cpiR = mean(cpiR))

# create regional names
cpi_avg <- cpi_avg %>% mutate(
  region = case_when(geo == "British Columbia" | geo == "Alberta" | geo == "Saskatchewan" | geo == "Manitoba"  ~ "west", 
                     geo == "Ontario" | geo == "Quebec" ~ "cent",
                    TRUE ~ "east"))

# calculate regional averages
cpi_summary <- cpi_avg %>% 
  filter(item != "all") %>%
  group_by(item,window,region) %>%
  summarise(cpi = mean(avg_cpi),
            cpiA = mean(avg_cpiA),
            cpiR = mean(avg_cpiR))

# create combined names
cpi_summary2 <- ungroup(cpi_summary) %>%
  mutate(header = paste(item,stri_sub(window,-3), sep = "")) %>%
  dplyr::select(-c(item,window))

# create a wider version of the previous table, and re-order columns
cpi_format <- ungroup(cpi_summary) %>%
  pivot_wider(names_from = region, values_from = c(cpi,cpiA,cpiR))  
  
# reorder columns
cpi_format <- cpi_format[,c(1,2,5,8,11,3,6,9,4,7,10)]
cpi_format



 

# ------------------------------
# Alternative way to change column names
#cpi <- cpi %>%
#  filter(item != "All-items") %>%
#  mutate(item = replace(item, item == "Bakery and cereal products (excluding baby food)", "cat1"),
#         item = replace(item, item == "Dairy products and eggs", "cat2"),
#         item = replace(item, item == "Fish, seafood and other marine products", "cat3"),
#         item = replace(item, item == "Food", "cat4"),
#         item = replace(item, item == "Fruit, fruit preparations and nuts", "cat5"),
#         item = replace(item, item == "Meat", "cat6"),
#         item = replace(item, item == "Other food products and non-alcoholic beverages", "cat7"),
#         item = replace(item, item == "Vegetables and vegetable preparations", "cat8"))


 