rm(list = ls())
pacman::p_load(tidyverse, here, janitor, lubridate, tsibble, gridExtra, urca, forecast, vars)

# read in the raw data

cpi_raw <- read_csv(here("data", "18100004.csv"), show_col_types = FALSE) %>% 
  clean_names() %>%
  mutate(date = ym(ref_date)) %>%
  dplyr::select(date,geo,products_and_product_groups,value) %>%
  rename(item = products_and_product_groups, cpi = value) 

cpi_province <- cpi_raw %>% 
  filter(item ==  "All-items" | 
           item == "Bakery products" |
           item == "Dairy products" |
           item == "Fish" |
           item == "Food" |
           item == "Fresh fruit" |
           item == "Meat" |
           item == "Other food products and non-alcoholic beverages" |
           item == "Fresh vegetables") %>%
  filter(geo ==  "British Columbia" | 
           geo == "Alberta" |
           geo == "Saskatchewan" |
           geo == "Manitoba" |
           geo == "Ontario" |
           geo == "Quebec" |
           geo == "New Brunswick" |
           geo == "Nova Scotia" |
           geo == "Prince Edward Island" |
           geo == "Newfoundland and Labrador") %>% 
  filter(date >= "1992-01-01" & date <= "2022-05-01") %>%
  mutate(year_month = yearmonth(date),
         year = year(date)) %>%
  as_tsibble(key = c(geo,item),index = year_month) %>%
  dplyr::select(-date)

# identify cpi in July of 2014 to create new base year
  
# first, create a new column which combines data and item
cpi_temp <- cpi_province %>% mutate(geo_item = paste(geo,item))

# next, filter row corresponding to July of 2014
base <- cpi_temp %>%
  filter_index("2014-07-01")
base

# now, use the "geo_item" column in cpi and base in a lookup procedure
# https://stackoverflow.com/questions/35636315/replace-values-in-a-dataframe-based-on-lookup-table
new <- cpi_temp[,"geo_item"]
new[] <- lapply(cpi_temp[,"geo_item"], function(x) base$cpi[match(x, base$geo_item)]) 

# finally, add new "base" column to cpi
new <- new %>% rename(base = geo_item)
cpi_province <- dplyr::bind_cols(cpi_temp,new)

# create cpia as the cpi with the adjusted July 2014 base year
 
cpi_province <- cpi_province %>%
  mutate(cpia = 100*cpi/base) %>%
  dplyr::select(year_month,year,geo,item,cpi,cpia)
   
# select the "All-items" cpi to be used as a base
cpi_all <- cpi_province %>%
  filter(item ==  "All-items") %>%
  rename(cpi_all = cpi,
         cpi_alla = cpia)  

# add the "All-items" cpi as a new column

cpi_province <- left_join(cpi_province,cpi_all[,c("year_month","geo","cpi_all","cpi_alla")], by = c("year_month"="year_month","geo"="geo")) %>%
  dplyr::select(year_month,year,geo,item,cpi,cpia,cpi_all,cpi_alla)

saveRDS(cpi_province,here("data","cpi_province.RDS")) 