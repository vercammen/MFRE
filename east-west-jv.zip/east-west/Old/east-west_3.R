rm(list = ls())
pacman::p_load(tidyverse, here, lubridate,tsibble, broom)

# import cleaned data
cpi <- readRDS(here("data","cpi_province1992.RDS"))  

# create item name abbreviations
cpi <- cpi %>%
  mutate(item = recode(item,
                       "All-items" = "all",
                       "Bakery and cereal products (excluding baby food)" = "bake",
                       "Dairy products and eggs" = "dairy",
                       "Fish, seafood and other marine products" = "fish",
                       "Food" = "food",
                       "Fruit, fruit preparations and nuts" = "fruit",
                       "Other food products and non-alcoholic beverages" = "other",
                       "Vegetables and vegetable preparations" = "veggies"
  ))
  
# create regional categorical variable
cpi <- cpi %>% mutate(
  region = case_when(geo == "British Columbia" | geo == "Alberta" | geo == "Saskatchewan" | geo == "Manitoba"  ~ "west", 
                     geo == "Ontario" | geo == "Quebec" ~ "cent",
                     TRUE ~ "east"))

# create regional averages with item and year_month categories preserved
# https://stackoverflow.com/questions/9723208/aggregate-summarize-multiple-variables-per-group-e-g-sum-mean
cpi_region <- as_tibble(cpi) %>% 
  group_by(year_month,item,region) %>% 
  summarise_at(vars(cpi, cpiA), mean) %>%
  arrange(item,region,year_month)


#cpi_region2 <- cpi %>%
#  group_by_key() %>%
#  index_by(year_month) %>%
#  summarise(
#    cpi = mean(cpi),
#    cpiA = mean(cpiA)
#  )


# pull out the food category and create a time trend for each region
cpi_food <- ungroup(cpi_region) %>%
  filter(item=="food") %>%
  dplyr::select(-item) %>%
  group_by(region) %>% mutate(trend = row_number(region)) %>%
  as_tsibble(index=year_month,key=region)

# create dummy variables for west and east, and interactions with trend
cpi_food = cpi_food %>% mutate(
  west = ifelse(region=="west",1,0),
  east = ifelse(region=="east",1,0),
  west_trend = west*trend,
  east_trend = east*trend
) 

# regress food cpi on trend and west-trend interaction (stop at end of 2011)
cpi_food_pre <- cpi_food %>%
  filter(year(year_month) < 2012)
z <- lm(cpi ~ trend+west_trend+east_trend, data = cpi_food_pre)
summary(z)

# conclude that prior to 2012 the west and trend followed a similar CPI path.

# to graph previous results we need to pivot wider
 
pre_graph <- as_tibble(cpi_food_pre) %>%
  dplyr::select(year_month,region,cpi,trend) %>%
  pivot_wider(names_from=c(region),values_from=c(cpi,trend)) %>%
  rename(trend = trend_cent)

# add fitted values
pre_graph <- pre_graph %>%
  mutate(cent_fit = z$coefficients[1]+z$coefficients[2]*trend,
         west_fit = z$coefficients[1]+(z$coefficients[2]+z$coefficients[3])*trend,
         east_fit = z$coefficients[1]+(z$coefficients[2]+z$coefficients[4])*trend)

# add 2012 - 2022 cpi_cent, cpi_west to pre_graph
combined <- rbind.fill(pre_graph, mtcars[c("wt", "cyl")])

test <- rep(NA,each=124)
test2 <- cbind()
pre_graph$cent_fit[241:365]=NA

all_graph <- cpi_food %>%
  mutate(cent_fit = pre_graph$cent_fit)


ggplot() + 
  geom_line(data = pre_graph, aes(x = year_month, y = cpi_cent), color = "blue") +
  geom_line(data = pre_graph, aes(x = year_month, y = cpi_west), color = "red") +
  geom_line(data = pre_graph, aes(x = year_month, y = cent_fit), color = "green") +
  geom_line(data = pre_graph, aes(x = year_month, y = cent_west), color = "black") +
  labs(y= "y (blue) and z (red)", x = "Month") 



# convert to long then graph
pre_graph_long <- pre_graph %>%
  dplyr::select(year_month,cpi_cent,cpi_west,cent_fit,west_fit)
  
test <- melt(pre_graph_long, id="year_month")   

ggplot(data=test_data_long,
       aes(x=date, y=value, colour=variable)) +
  geom_line()

  



# create dummies for each 5 years beginning in 1997 (1992 - 96 omitted)
# create interactions: early10*west, late10*west, early10*east, late10*east
cpi_food = cpi_food %>% mutate(
  year = year(year_month),
  late90 = ifelse(year >=1997 & year <= 2001,1,0),
  early00 = ifelse(year >=2002 & year <= 2006,1,0),
  late00 = ifelse(year >=2007 & year <= 2011,1,0),
  early10 = ifelse(year >=2012 & year <= 2016,1,0),
  late10 = ifelse(year >=2017 & year <= 2022,1,0),
  early10_w = early10*west,
  late10_w = late10*west,
  early10_e = early10*east,
  late10_e = late10*east
  ) 

# regress food cpi on time, regional and interaction dummies

summary(lm(cpi ~ west+east +late90+early00+late00+early10+late10+early10_w+late10_w , data = cpi_food))

 


# run regression with subsetted data
 # use tidy function: https://cran.r-project.org/web/packages/broom/vignettes/broom.html

dfcpi = cpi %>% group_by(item) %>%
  do(fitcpi = lm(neta~late90+early00+late00+early10+late10+west+east+early10_w+late10_w+early10_e+late10_e, data = .))
results <- lapply(dfcpi$fitcpi, tidy )

# loop through to display the estimation results
for (i in 1:8)
{
  print(i)
  print(eval(parse(text = paste0("cat",i))))
  print(results[[i]])
}
 

# to graph the regional data we need to widen and then combine provinces into regions 
# choose which category (e.g., "cat4" - Food) to graph
 
category <- "cat4"

# widen  
cpi_wide <- as_tibble(cpi) %>%
  filter(item == category) %>%
  dplyr::select(year_month,geo,net) %>%
  pivot_wider(names_from = geo, values_from = net) %>%
  rename(w1 = "British Columbia",
         w2 = "Alberta",
         w3 = "Saskatchewan",
         w4 = "Manitoba",
         c1 = "Ontario",
         c2 = "Quebec",
         e1 = "New Brunswick",
         e2 = "Nova Scotia",
         e3 = "Prince Edward Island",
         e4 = "Newfoundland and Labrador"
         )

# create regional mean values
cpi_wide <- cpi_wide %>%
  mutate(west = (w1+w2+w3+w4)/4,
         central = (c1+c2)/2,
         east = (e1+e2+e3+e4)/4) %>%
  dplyr::select(year_month,west,central,east)

# graph the results
# create long version of "cpi_wide"
cpi_long <- cpi_wide %>% 
  pivot_longer(!year_month, names_to = "region", values_to = "cpi")

# graph the results 
cpi_long %>%
  ggplot( aes(x=year_month, y=cpi, group=region, color=region)) +
  geom_line()

