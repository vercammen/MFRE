# https://www.annualreviews.org/doi/pdf/10.1146/annurev-publhealth-040617-013507
rm(list = ls())
pacman::p_load(tidyverse, here, lubridate,tsibble, broom, fixest)

# import cleaned data
cpi <- readRDS(here("data","cpi_province1992.RDS"))  

# Filter out "all-items" and create real cpi variable
cpi <- as_tibble(cpi) %>%
  filter(item != "all") %>%
  mutate(cpiR = cpi/cpiA*100)

# relabel item names
cpi <- cpi %>%    
  mutate(item = recode(item,
                       "All-items" = "all",
                       "Bakery and cereal products (excluding baby food)" = "bake",
                       "Dairy products and eggs" = "dairy",
                       "Fish, seafood and other marine products" = "fish",
                       "Food" = "food",
                       "Fruit, fruit preparations and nuts" = "fruit",
                       "Other food products and non-alcoholic beverages" = "other",
                       "Vegetables and vegetable preparations" = "veggies"
  ))
  
# create province name abbreviations
cpi <- cpi %>%
  mutate(geo = recode(geo,
                       "Alberta" = "AB",
                       "British Columbia" = "BC",
                       "Manitoba" = "MB",
                       "New Brunswick" = "NB",
                       "Newfoundland and Labrador" = "NFL",
                       "Nova Scotia" = "NS",
                       "Ontario" = "aaON",
                       "Prince Edward Island" = "PEI",
                       "Quebec" = "QC",
                       "Saskatchewan" = "SK"
  ))

# declare as panel data with "item" as the "time" variable
#cpi.p <- pdata.frame(cpi,index=c("year_month","geo","item"))

# create regional categorical variable
cpi <- cpi %>% mutate(
  region = case_when(geo == "BC" | geo == "AB" | geo == "SK" | geo == "MB"  ~ "west", 
                     geo == "aaON" | geo == "QC" ~ "cent",
                     TRUE ~ "east"))

# create an indicator variable for western provinces post 2011

cpi <- cpi %>% mutate(
  west = ifelse(region=="west",1,0),
  post = ifelse(year(year_month) > 2011,1,0),
  west_post = west*post) %>%
  dplyr::select(-region)

# estimate diff-diff model with dummies for year, geo and item
model <- lm(cpi~0+factor(year)+factor(geo)+factor(item)+west_post,data=cpi)
summary(model)

# repeat for real cpi
model_R <- lm(cpiR~0+factor(year)+factor(geo)+factor(item)+west_post,data=cpi)
summary(model_R)

# graph regional cpi values
# see "east-west_jv.R"


# two way fixed effects estimation
# https://stackoverflow.com/questions/61633179/model-with-three-fixed-effects-in-plm-package-in-r

#fixed <- plm(cpi ~ west_post+factor(year_month), data=cpi, index=c("geo", "item"), model='within', effect="twoways")
#summary(fixed)

# https://cran.r-project.org/web/packages/fixest/vignettes/fixest_walkthrough.html#1_simple_example_using_trade_data
model2 = feols(cpi ~ west_post |item + geo + year , cpi)
summary(model2, vcov = "twoway")
summary(model2, vcov = ~ geo)

model2_R = feols(cpiR ~ west_post |item + geo + year , cpi)
summary(model2_R, vcov = "twoway")
summary(model2_R, vcov = ~ geo)