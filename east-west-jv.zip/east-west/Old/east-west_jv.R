rm(list = ls())
pacman::p_load(tidyverse, here, lubridate,tsibble, broom)

# import cleaned data
cpi <- readRDS(here("data","cpi_province1992.RDS"))  

# create item name abbreviations
cpi <- cpi %>%
  mutate(item = recode(item,
                       "All-items" = "all",
                       "Bakery and cereal products (excluding baby food)" = "bake",
                       "Dairy products and eggs" = "dairy",
                       "Fish, seafood and other marine products" = "fish",
                       "Food" = "food",
                       "Fruit, fruit preparations and nuts" = "fruit",
                       "Other food products and non-alcoholic beverages" = "other",
                       "Vegetables and vegetable preparations" = "veggies"
  ))
  
# create regional categorical variable
cpi <- cpi %>% mutate(
  region = case_when(geo == "British Columbia" | geo == "Alberta" | geo == "Saskatchewan" | geo == "Manitoba"  ~ "west", 
                     geo == "Ontario" | geo == "Quebec" ~ "cent",
                     TRUE ~ "east"))

# create regional averages with item and year_month categories preserved
# https://stackoverflow.com/questions/9723208/aggregate-summarize-multiple-variables-per-group-e-g-sum-mean
cpi_region <- as_tibble(cpi) %>% 
  group_by(year_month,item,region) %>% 
  summarise_at(vars(cpi, cpiA), mean) %>%
  arrange(item,region,year_month)


#cpi_region2 <- cpi %>%
#  group_by_key() %>%
#  index_by(year_month) %>%
#  summarise(
#    cpi = mean(cpi),
#    cpiA = mean(cpiA)
#  )


# pull out the food category and create a time trend for each region
cpi_food <- ungroup(cpi_region) %>%
  filter(item=="food") %>%
  dplyr::select(-item) %>%
  group_by(region) %>% 
  mutate(trend = row_number(region),
         trdsq = trend*trend) %>%
  as_tsibble(index=year_month,key=region)

# create dummy variables for west and east, and interactions with trend
# add west post 2012 dummy and interact with west_trend and west_trsq
cpi_food = cpi_food %>% mutate(
  west = ifelse(region=="west",1,0),
  east = ifelse(region=="east",1,0),
  post = ifelse(year(year_month)>2011,1,0),
  west_trend = west*trend,
  east_trend = east*trend,
  west_trdsq = west*trdsq,
  east_trdsq = east*trdsq,
  west_post = west*post
   ) 

# create wide version of data for use below
cpi_wide <- as_tibble(cpi_food) %>%
  dplyr::select(year_month,region,cpi,trend) %>%
  pivot_wider(names_from=c(region),values_from=c(cpi,trend)) %>%
  rename(trend = trend_cent)  

# regress food cpi on trend and west-trend interaction (stop at end of 2011)
cpi_food_pre <- cpi_food %>%
  filter(year(year_month) < 2012)
z <- lm(cpi ~ trend+trdsq+west_trend+east_trend+west_trdsq+east_trdsq, data = cpi_food_pre)
summary(z)

# conclude that prior to 2012 the west and trend followed a similar CPI path.

# add fitted values to cpi_wide with NA for post 2011 data
cpi_wide <- cpi_wide %>%
  mutate(cent_fit = ifelse(year(year_month)<2012,z$coefficients[1]+z$coefficients[2]*trend+z$coefficients[3]*trend^2,NA),
         west_fit = ifelse(year(year_month)<2012,z$coefficients[1]+(z$coefficients[2]+z$coefficients[4])*trend+(z$coefficients[3]+z$coefficients[6])*trend^2,NA),
         east_fit = ifelse(year(year_month)<2012,z$coefficients[1]+(z$coefficients[2]+z$coefficients[5])*trend+(z$coefficients[3]+z$coefficients[7])*trend^2,NA))

# create version of cpi_wide between 2000 and 2011, and beginning in 2005
cpi_wide_pre <- cpi_wide %>%
  filter(year(year_month) < 2012 & year(year_month) > 2004)

cpi_wide_post <- cpi_wide %>%
  filter(year(year_month) > 2011)

# plot data prior to 2012

ggplot() + 
  geom_line(data = cpi_wide_pre, aes(x = year_month, y = cpi_cent), color = "blue") +
  geom_line(data = cpi_wide_pre, aes(x = year_month, y = cpi_west), color = "red") +
  geom_line(data = cpi_wide_pre, aes(x = year_month, y = cpi_east), color = "green") +
  geom_line(data = cpi_wide_pre, aes(x = year_month, y = cent_fit), color = "black") +
  labs(y= "center (blue), west (red), east (green), trend (black)", x = "Month") 

 
# plot data after 2011

ggplot() + 
  geom_line(data = cpi_wide_post, aes(x = year_month, y = cpi_cent), color = "blue") +
  geom_line(data = cpi_wide_post, aes(x = year_month, y = cpi_west), color = "red") +
  geom_line(data = cpi_wide_post, aes(x = year_month, y = cpi_east), color = "green") +
  labs(y= "center (blue), west (red), east (green)", x = "Month") 


# estimate diff-in-diff model
# regress food cpi on trend and west-trend interaction (stop at end of 2011)
 
dd <- lm(cpi ~ trend+trdsq+west_trend+east_trend+west_trdsq+east_trdsq+post+west_post, data = cpi_food)
summary(dd)

# add diff-in-diff fitted values to cpi_wide  
cpi_full <- cpi_wide %>%
  dplyr::select(-c("cent_fit","west_fit","east_fit")) %>%
  mutate(cent_fit = dd$coefficients[1]+dd$coefficients[2]*trend+dd$coefficients[3]*trend^2,
         west_fit = dd$coefficients[1]+(dd$coefficients[2]+dd$coefficients[4])*trend+(dd$coefficients[3]+dd$coefficients[6])*trend^2,
         east_fit = dd$coefficients[1]+(dd$coefficients[2]+dd$coefficients[5])*trend+(dd$coefficients[3]+dd$coefficients[7])*trend^2)

# graph
ggplot() + 
  geom_line(data = cpi_full, aes(x = year_month, y = cpi_cent), color = "blue") +
  geom_line(data = cpi_full, aes(x = year_month, y = cpi_west), color = "red") +
  geom_line(data = cpi_full, aes(x = year_month, y = cpi_east), color = "green") +
  geom_line(data = cpi_full, aes(x = year_month, y = cent_fit), color = "black",  size = 1)
  labs(y= "center (blue), west (red), east (green)", x = "Month") 


# create dummies for each 5 years beginning in 1997 (1992 - 96 omitted)
# create interactions: early10*west, late10*west, early10*east, late10*east
cpi_food = cpi_food %>% mutate(
  year = year(year_month),
  late90 = ifelse(year >=1997 & year <= 2001,1,0),
  early00 = ifelse(year >=2002 & year <= 2006,1,0),
  late00 = ifelse(year >=2007 & year <= 2011,1,0),
  early10 = ifelse(year >=2012 & year <= 2016,1,0),
  late10 = ifelse(year >=2017 & year <= 2022,1,0),
  early10_w = early10*west,
  late10_w = late10*west,
  early10_e = early10*east,
  late10_e = late10*east
  ) 

# regress food cpi on time, regional and interaction dummies

summary(lm(cpi ~ west+east +late90+early00+late00+early10+late10+early10_w+late10_w , data = cpi_food))

 


# run regression with subsetted data
 # use tidy function: https://cran.r-project.org/web/packages/broom/vignettes/broom.html

dfcpi = cpi %>% group_by(item) %>%
  do(fitcpi = lm(neta~late90+early00+late00+early10+late10+west+east+early10_w+late10_w+early10_e+late10_e, data = .))
results <- lapply(dfcpi$fitcpi, tidy )

# loop through to display the estimation results
for (i in 1:8)
{
  print(i)
  print(eval(parse(text = paste0("cat",i))))
  print(results[[i]])
}
 

# to graph the regional data we need to widen and then combine provinces into regions 
# choose which category (e.g., "cat4" - Food) to graph
 
category <- "cat4"

# widen  
cpi_wide <- as_tibble(cpi) %>%
  filter(item == category) %>%
  dplyr::select(year_month,geo,net) %>%
  pivot_wider(names_from = geo, values_from = net) %>%
  rename(w1 = "British Columbia",
         w2 = "Alberta",
         w3 = "Saskatchewan",
         w4 = "Manitoba",
         c1 = "Ontario",
         c2 = "Quebec",
         e1 = "New Brunswick",
         e2 = "Nova Scotia",
         e3 = "Prince Edward Island",
         e4 = "Newfoundland and Labrador"
         )

# create regional mean values
cpi_wide <- cpi_wide %>%
  mutate(west = (w1+w2+w3+w4)/4,
         central = (c1+c2)/2,
         east = (e1+e2+e3+e4)/4) %>%
  dplyr::select(year_month,west,central,east)

# graph the results
# create long version of "cpi_wide"
cpi_long <- cpi_wide %>% 
  pivot_longer(!year_month, names_to = "region", values_to = "cpi")

# graph the results 
cpi_long %>%
  ggplot( aes(x=year_month, y=cpi, group=region, color=region)) +
  geom_line()

