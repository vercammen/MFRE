## https://faculty.washington.edu/ezivot/econ424/Working%20with%20Time%20Series%20Data%20in%20R.pdf
# execution error (error retrieving help): https://stackoverflow.com/questions/59000627/how-do-i-solve-the-r-code-execution-error-on-rstudio

rm(list = ls())


pacman::p_load(tsibble,lubridate,tidyverse,xts,timetk,here)  

####### ts vs xts objects
# follow https://stackoverflow.com/questions/11858481/lagging-xts-objects-in-r
# the following is a ts object (applicable for regularly spaced time series)
ldeaths
str(ldeaths)

# to lag the variable by one year we need to use -12 rather than 12 --> no NAs
ldeaths_lag <- stats::lag(ldeaths, -12)
head(ldeaths_lag, 14)
str(ldeaths_lag)

# we cannot delete the first observation --> converts to a double
ldeaths_del <- ldeaths[-1]
head(ldeaths_del, 14)
str(ldeaths_del)

# convert to an xts object 
ldeaths.x = as.xts(ldeaths)
head(ldeaths, 14)
str(ldeaths.x)

# now lag the xts object --> lag works in the expected way, NAs appear
ldeaths.x_lag <- stats::lag(ldeaths.x, 12)
head(ldeaths.x_lag, 14)
str(ldeaths.x_lag)

# first difference (monthly) --> object converted to ts??? convert back to xts
ldeaths.x_dif <- as.xts(diff(ldeaths, lag = 1, differences = 1))
head(ldeaths.x_dif, 14)
str(ldeaths.x_dif)

# combine regular, lagged and difference xts variables;  
ldeaths.x_combine <- merge(ldeaths.x, ldeaths.x_lag, join = "inner")
head(ldeaths.x_combine, 14)
str(ldeaths.x_combine)

# delete first 4 rows of combined xts object
ldeaths.x_combine_del <- ldeaths.x_combine[-c(1:4),]
head(ldeaths.x_combine_del, 14)
str(ldeaths.x_combine_del)

##### convert regular spaced tibble to xls object

# import external tibble: https://business-science.github.io/timetk/articles/TK00_Time_Series_Coercion.html
q10 <- m4_quarterly %>% filter(id == "Q10")
head(q10)

# converting the full tibble to a time series (ts) converts the date to a double - no good.
ts(q10, start = c(2000, 1), freq = 4) %>% head()

# a single column can be extracted and converted to a time series but the date column is then lost
q10ts <- ts(q10$value, start = c(2000, 1), freq  = 4)
q10ts
str(q10ts)

# convert q10ts to an xts variable
q10xts <- as.xts(q10ts)
q10xts
str(q10xts)

# https://stackoverflow.com/questions/11858481/lagging-xts-objects-in-r
# q10xts_lag <- lag(q10xts, -4)

# teaching will mostly involved importing csv data with regular or irregular dates
# importing csv data with regular dates will be the same as the tibble example above
# what follows is a made up data set of irregularly spaced data

trade_date <- c("Feb 7 2022", "Feb 8 2022", "Feb 9 2022", "Feb 10 2022", "Feb 11 2022", "Feb 14 2022", "Feb 15 2022")
var1 <- c(10, 13, 9, 11, 6, 15, 12)
var2 <- c(26, 31, 17, 24,30, 22,26)
var3 <- c(102, 114, 109, 105, 131, 107, 101)

# create a tibble
data <- tibble(trade_date, var1,var2,var3)
data 

# create a tibble
data <- tibble(trade_date, var1,var2,var3)
data 

# we can construct lags for this tibble
data_lag <- data %>% mutate(L.var1 = lag(var1),L.var2 = lag(var2),L.var3 = lag(var3))
data_lag

# we can construct differences for this tibble
data_dif <- data %>% mutate(D.var1 = difference(var1),D.var2 = difference(var2),D.var3 = difference(var3))
data_dif

# convert the tibble to an xts object and within convert character date to date object 
# make use of "new" tk_xts() function rather than using xts() function.

data_xts <- data %>%
  mutate(date = mdy(trade_date)) %>%
  mutate(date2 = as.Date(date)) %>%
  select(-trade_date,-date) %>%
  tk_xts(date_var = date2) 

data_xts
str(data_xts)

## repeat previous procedure but start with data read from csv
# the read_csv() function reads data into a tibble
# conversion to xts is the same as previous example

data2 <- read_csv(here("data", "test.csv"))

data2_xts <- data2 %>%
  mutate(date = mdy(trade_date)) %>%
  mutate(date2 = as.Date(date)) %>%
  select(-trade_date,-date) %>%
  tk_xts(date_var = date2)

data2_xts
str(data2_xts)


### create lags and differences of data_xts object

# lag all columns of data_xts two times
data_lag2 <- stats::lag(data_xts, 2)
data_lag2 <- merge(data_xts, data_lag2, join = "inner") # columns must now be renamed
data_lag2

# caculate the first difference of data_xts
data_dif1 <- diff(data_xts, lag=1,differences=1)
data_dif1 <- merge(data_xts, data_dif1, join = "inner") 
data_dif1

## dplyr functions, including mutate(), do not work with xts objects.
## Convert tibble to tsibble and then work with dplyr functions.
# convert trade_date to date object using lubridate function, then convert to tsibble
data_tsi <- data %>%
  select(-trade_date) %>%
  mutate(date = mdy(trade_date), .before = var1) %>%
  as_tsibble(index = date)
data_tsi

# use mutate to add a second lag to each of the three variables
data_tsi_lag2 <- data_tsi %>% mutate(L2.var1 = lag(var1,2),L2.var2 = lag(var2,2),L2.var3 = lag(var3,2))
data_tsi_lag2

# use mutate to add a first difference to each of the three variables
# use the difference function from tsibble package rather than diff()
data_tsi_dif <- data_tsi %>% mutate(D.var1 = difference(var1),D.var2 = difference(var2),D.var3 = difference(var3)) 
data_tsi_dif

# drop all columns except date and a newly created lag2 column
v1_lag2 <- data_tsi %>% mutate(L2.var2 = stats::lag(var2,2)) %>% select(date,L2.var2)
v1_lag2 

# create large tsibble object with three lagged differences
data_full <- data_tsi %>% mutate(D.var1=difference(var1),D.var2=difference(var2),D.var3=difference(var3)) %>%
  mutate(DL.var1=lag(D.var1),DL.var2=lag(D.var2),DL.var3=lag(D.var3) ) %>%
  mutate(DL2.var1=lag(D.var1, 2),DL2.var2=lag(D.var2,2),DL2.var3=lag(D.var3,2) ) %>%
  mutate(DL3.var1=lag(D.var1, 3),DL3.var2=lag(D.var2,3),DL3.var3=lag(D.var3,3) )

# write data_full to csv file
# write_csv(data_full, here("data", "data_full.csv"))

# filter data to eliminate NA in top rows (as a function of lags)
lags <- 2
data_full_r <- data_full %>% filter(!row_number() %in% c(1:lags))