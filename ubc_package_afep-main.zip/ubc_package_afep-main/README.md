
<!-- README.md is generated from README.Rmd. Please edit that file -->

# afep

<!-- badges: start -->
<!-- badges: end -->

The goal of afep is to provide the data files to run the examples in
James Vercammen’s “Time Series Analysis of Food and Energy Prices” book.

## Installation

You can install the development version of afep from
[GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("sazh1/ubc_package_afep")
```

Load the package using:

``` r
library(afep)
```
