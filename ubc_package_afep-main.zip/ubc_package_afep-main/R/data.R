#' Global banana prices
#'
#' A `tsibble` data set containing monthly global price of bananas
#'
#' @source <https://www.indexmundi.com/commodities/?commodity=bananas&months=240>
#' @name afep_bananas
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{price}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_bananas"

#' Vegetable oils and biofuels
#'
#' A `tsibble` data set containing weekly prices of vegetable oils and biofuels
#'
#' @source <https://www.card.iastate.edu/research/biorenewables/tools/hist_bio_gm.aspx>,
#'         <http://www.eia.gov/oog/info/wohdp/diesel.asp>,
#'         <https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=PET&s=RWTC&f=W>
#' @name afep_biofuel
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{week}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{biodiesel}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{soy_oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{diesel}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{crude}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_biofuel"

#' Simulated structural break data
#'
#' A vector containing simulated trend stationary data
#'
#' @name afep_break_simulate
#' @docType data
#' @format A vector containing the simulated observations
#' @keywords data sets
"afep_break_simulate"

#' Corn prices and USD/MXN rates
#'
#' A `tsibble` data set containing monthly U.S. corn prices and U.S. - Mexico
#' exchange rates
#'
#' @source <https://www.ers.usda.gov/data-products/feed-grains-database/>,
#'         <https://fred.stlouisfed.org/series/EXMXUS>
#' @name afep_corn
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month, month_ind, year}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{corn}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{avg_year}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{deviate}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{exchange_r_mex}{1 USD = ?? MXN}
#' }
#' @keywords data sets
"afep_corn"

#' U.S. CPI
#'
#' A `tsibble` data set containing monthly U.S. CPI
#'
#' @source <https://fred.stlouisfed.org/series/CPIAUCSL>
#' @name afep_cpi_month
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{cpi}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_cpi_month"

#' Oil futures prices
#'
#' A `tsibble` data set containing daily crude oil futures prices
#'
#' @source <https://eodhistoricaldata.com>
#' @name afep_crude_daily
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{date}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{open}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{high}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{low}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{close}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{adjusted_close}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{volume}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_crude_daily"

#' ARIMA data
#'
#' A `tsibble` data set containing simulated ARIMA data
#'
#' @source Name of data provider? <URL if Available>
#' @name afep_data_sim
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{quarter_1}{change the name to "quarter_ind" and update the package. Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{z_1}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{z_2}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{x_1}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_data_sim"

#' Egg prices
#'
#' A `tsibble` data set containing monthly producer price of eggs in the
#' Province of Alberta, Canada
#'
#' @source <https://agriculture.canada.ca/en/market-information-system/rp/index-eng.cfm?action=pR&r=16&pdctc=&wbdisable=true>
#' @name afep_eggs
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{price}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{month}{Month in `yearmonth` format}
#' }
#' @keywords data sets
"afep_eggs"

#' Energy and temperature
#'
#' A `tsibble` data set containing monthly U.S. residential energy use,
#' electricity price and temperature anomaly
#'
#' @source <https://www.eia.gov/totalenergy/data/monthly/>,
#'         <https://www.ncei.noaa.gov/access/monitoring/national-temperature-index/time-series/anom-tavg/1/12>
#' @name afep_energy_temp
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{energy}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{electricity}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{temperature}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_energy_temp"

#' Fruits
#'
#' A `tsibble` data set containing monthly U.S. prices for strawberries and
#' grapes and U.S. - Mexico exchange rates
#'
#' @source <https://fred.stlouisfed.org/series/APU0000711415>,
#'         <https://fred.stlouisfed.org/series/APU0000711417>,
#'         <https://fred.stlouisfed.org/series/EXMXUS>
#' @name afep_fruit
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{strawberry}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{grape}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{exchange_r_mex}{1 USD = ?? MXN}
#' \item{month_ind}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{year}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_fruit"

#' Gasoline prices in Canada
#'
#' A `tsibble` data set containing monthly price of unleaded gasoline in
#' Vancouver and Winnipeg, Canada
#'
#' @source <https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810000101>
#' @name afep_gas_city
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{vancouver}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{winnipeg}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{premium}{vancouver - winnipeg}
#' }
#' @keywords data sets
"afep_gas_city"

#' Gasoline prices
#'
#' A `tsibble` data set containing the seasonally adjusted and non-adjusted U.S.
#' gasoline price (monthly)
#'
#' @source <https://fred.stlouisfed.org/series/CUSR0000SETB01>,
#'         <https://fred.stlouisfed.org/series/CUUR0000SETB01>
#' @name afep_gasoline
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{gasoline_sa}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{gasoline}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_gasoline"

#' Hog prices
#'
#' A `tsibble` data set containing monthly data on the slaughter hog producer
#' price index, the U.S. - Canada exchange rate., and the price of West Texas
#' Intermediate crude oil
#'
#' @source <https://fred.stlouisfed.org/series/WPU0132>,
#'         <https://fred.stlouisfed.org/series/EXCAUS>
#' @name afep_hogs
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{hogs}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{exchange_r_can}{1 USD = ?? CAN}
#' \item{oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_hogs"

#' U.S. industrial production index
#'
#' A `tsibble` data set containing a measure of monthly U.S. industrial
#' production (electric and gas utilities)
#'
#' @source <https://fred.stlouisfed.org/series/IPUTIL>
#' @name afep_industrial
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{industrial}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_industrial"

#' Oil prices and U.S. dollar
#'
#' A `tsibble` data set containing monthly prices of West Texas Intermediate
#' (wti), Western Canada Select (wcs) crude oil, and the U.S. dollar index
#'
#' @source <https://economicdashboard.alberta.ca/oilprice>,
#'         <https://fred.stlouisfed.org/series/TWEXBGSMTH>
#' @name afep_oil
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{wti}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{wcs}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{dollar}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_oil"

#' Price of power resources
#'
#' A `tsibble` data set containing monthly U.S. spark spread, and electricity
#' and natural gas prices
#'
#' @source <https://fred.stlouisfed.org/series/CUUR0000SEHF01>,
#'         <https://fred.stlouisfed.org/series/MHHNGSP>
#' @name afep_power
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{gas_sa}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{elect_sa}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{spark_spread}{Gross margin earned by plants which produce electricity
#' from natural gas}
#' }
#' @keywords data sets
"afep_power"

#' Potato prices
#'
#' A `tsibble` data set containing an index of the farm price of potatoes in U.S.
#'
#' @source <https://fred.stlouisfed.org/series/WPU01130603>
#' @name afep_ppi_potato
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{ppi}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_ppi_potato"

#' Diesel fuel, rainfall and vegetable CPI
#'
#' A `tsibble` data set containing monthly data on U.S. fruit and vegetable CPI,
#' price of diesel fuel, and drought variables for six agricultural counties in
#' California
#'
#' @source <https://fred.stlouisfed.org/series/CUSR0000SAF113>,
#'         <https://fred.stlouisfed.org/series/GASDESW>,
#'         <https://droughtmonitor.unl.edu/DmData/DataTables.aspx?state,ca>
#' @name afep_veggie
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{veggies}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{diesel}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{d_2_4}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{d_3_4}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{d_4}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{month_2}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_veggie"

#' Vegetable oils
#'
#' A `tsibble` data set containing monthly prices of vegetable oils
#'
#' @source <https://www.worldbank.org/en/research/commodity-markets>
#' @name afep_veggie_oils
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{palm_oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{soybean_oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{rapeseed_oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_veggie_oils"

#' Wheat and oil prices
#'
#' A `tsibble` data set containing monthly global price of wheat and price of West Texas
#' Intermediate (WTI) oil
#'
#' @source <https://fred.stlouisfed.org/series/PWHEAMTUSDM>,
#'         <https://fred.stlouisfed.org/series/MCOILWTICO>
#' @name afep_wheat_oil
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Month in `yearmonth` format}
#' \item{p_wheat}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{p_oil}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_wheat_oil"

#' Wood and heating oil premiums
#'
#' A `tsibble` data set containing monthly U.S. data on wood and heating oil premiums
#'
#' @source <https://fred.stlouisfed.org/series/PCU3211133211135>,
#'         <https://fred.stlouisfed.org/series/WPU083>,
#'         <https://fred.stlouisfed.org/series/WPU05730201>
#' @name afep_wood
#' @docType data
#' @format Time series of class `tsibble` with columns:
#' \describe{
#' \item{month}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{prem_e}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{prem_w}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{period}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{temp}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' \item{lag_1_temp, lag_2_temp}{Add description; ask prof. Vercammen to check the documentation especially source links}
#' }
#' @keywords data sets
"afep_wood"
