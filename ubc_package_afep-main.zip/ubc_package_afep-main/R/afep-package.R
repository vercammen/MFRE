#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom lmtest coeftest
#' @importFrom sandwich bread
#' @importFrom sandwich estfun
#' @importFrom sandwich vcovHC
#' @importFrom stats as.formula
#' @importFrom stats lm
#' @importFrom stats vcov
## usethis namespace: end
NULL
