rds_files_1 <- list.files("c:/sajad/ubc/book_ts/ch_3/data/ch_3", pattern = "^afep",
                          full.names = TRUE)

rds_files_2 <- list.files("c:/sajad/ubc/book_ts/ch_3/data/ch_3", pattern = "^afep",
                          full.names = FALSE)

rds_files_2 <- gsub('.RDS','', rds_files_2)

for (i in 1:length(rds_files_1)){
  assign(rds_files_2[i], readRDS(rds_files_1[i]))
}

usethis::use_data(afep_bananas, overwrite = TRUE)
usethis::use_data(afep_biofuel, overwrite = TRUE)
usethis::use_data(afep_break_simulate, overwrite = TRUE)
usethis::use_data(afep_corn, overwrite = TRUE)
usethis::use_data(afep_cpi_month, overwrite = TRUE)
usethis::use_data(afep_crude_daily, overwrite = TRUE)
usethis::use_data(afep_data_sim, overwrite = TRUE)
usethis::use_data(afep_eggs, overwrite = TRUE)
usethis::use_data(afep_energy_temp, overwrite = TRUE)
usethis::use_data(afep_fruit, overwrite = TRUE)
usethis::use_data(afep_gas_city, overwrite = TRUE)
usethis::use_data(afep_gasoline, overwrite = TRUE)
usethis::use_data(afep_hogs, overwrite = TRUE)
usethis::use_data(afep_industrial, overwrite = TRUE)
usethis::use_data(afep_oil, overwrite = TRUE)
usethis::use_data(afep_power, overwrite = TRUE)
usethis::use_data(afep_ppi_potato, overwrite = TRUE)
usethis::use_data(afep_veggie, overwrite = TRUE)
usethis::use_data(afep_veggie_oils, overwrite = TRUE)
usethis::use_data(afep_wheat_oil, overwrite = TRUE)
usethis::use_data(afep_wood, overwrite = TRUE)

# afep_dates_sample <- readr::read_csv("C:/sajad/ubc/book_ts/ch_2/chapter_2/chapter_2/data/ch2/dates_sample.csv",
#                                col_types = readr::cols(
#                                  readr::col_date("%m/%d/%Y"),
#                                  readr::col_character(),
#                                  readr::col_date("%d/%m/%Y"),
#                                  readr::col_double(),
#                                  readr::col_character()
#                                )
#                                )
#
# names(afep_dates_sample) <- c("date_1","date_2","date_3","date_year","date_month")
# usethis::use_data(afep_dates_sample, overwrite = TRUE)
