
rm(list = ls())
pacman::p_load(tidyverse, here, readxl, janitor, xts, lubridate, urca, tsibble)

### Read and Clean Veggie Oil Data into a tsibble
# When reading data, ask R to read .. as missing
cmo <- read_excel(here("data", "CMO-Historical-Data-Monthly.xlsx"),
                  sheet = "Monthly Prices", skip = 4, na = "..") %>%
  clean_names()

cmo <- cmo %>%
  rename(date = x1) %>%
  dplyr::select(date, palm_oil, soybean_oil, rapeseed_oil) %>%
  filter(!is.na(date) & !is.na(rapeseed_oil)) %>%
  mutate(date = as.Date(paste0(date, "01"), "%YM%m%d")) %>%
  filter(date >= "2003-01-01" & date <= "2020-12-01") %>%
  mutate(lnpalm = log(as.numeric(palm_oil)),
         lnsoy = log(as.numeric(soybean_oil)),
         lnrapeseed = log(as.numeric(rapeseed_oil)))

# convert cmo tibble to tsibble object
cmo <- cmo %>% as_tsibble(index = date)

# saveRDS(cmo, here("data", "vegoils.RDS"))


### Read and clean biodiesel data into a tibble
# read in data and rename columns
iowa_data <- read_csv(here("data", "hist_bio_gm.csv"), skip = 2) %>%
  dplyr::select(1:3) %>%
  dplyr::rename(date = 1, biodiesel = 2, soyoil = 3) %>%
  mutate(date = mdy(date)) # convert character to date format

diesel_data <- readxl::read_excel(here("data","Diesel Fuel Prices-EIA.xls"), sheet = "Data 1", skip = 2)  %>% 
  dplyr::select(1,2) %>%
  dplyr::rename(date = 1, diesel = 2) 

crude_data <- readxl::read_excel(here("data","Crude Oil Prices-EIA.xls"), sheet = "Data 1", skip = 2)  %>% 
  dplyr::select(1,2) %>%
  dplyr::rename(date = 1, crude = 2) 

# convert the dates to tsibble week labels to ensure consistent dates in all data frames

iowa_data <- iowa_data %>% mutate(week = yearweek(date)) %>% as_tibble(index=week) %>% dplyr::select(-date)
diesel_data <- diesel_data %>% mutate(week = yearweek(date)) %>% as_tibble(index=week) %>% dplyr::select(-date)
crude_data <- crude_data %>% mutate(week = yearweek(date)) %>% as_tibble(index=week) %>% dplyr::select(-date)

# join data and delete any duplicate rows

diesel_crude <- left_join(diesel_data, crude_data,by="week")
data <- left_join(iowa_data,diesel_crude,by="week") %>% 
  relocate(week, .after = last_col()) %>%
  as_tibble(index=week) %>% distinct()

# convert data to tsibble
data <- data %>% as_tsibble(index = week) 

# identify data gaps

data_gaps <- data %>% 
  count_gaps(.full = TRUE)
data_gaps

# interpolate missing values
data2 <- data %>% 
  fill_gaps(.full = TRUE) %>%
  mutate(biodiesel = na.interp(biodiesel),soyoil = na.interp(soyoil), diesel = na.interp(diesel), crude = na.interp(crude))  
      
# create logged values and select these for further analysis
lnp <- data2 %>% mutate(lnbio = log(biodiesel),lnsoy=log(soyoil), lndiesel=log(diesel),lncrude=log(crude))  %>%
  dplyr::select(lnbio,lnsoy,lndiesel,lncrude) %>%
  relocate(week)

# saveRDS(lnp, here("data", "lnp.RDS"))

### read and clean data for lumber
# U.S. lumber
lumbUSA <- read_csv(here("data", "Lumber Assortment USA.csv"))
# convert "jan, feb, etc" to numeric, create single date from two date columns the convert to R date
lumbUSA <- lumbUSA %>% mutate(date = ymd(paste(year, match(month,month.abb), "1", sep="-"))) %>%
   select(!c(year,month))

# Swedish lumber (select relevant columns and rows)
lumbSWD <- readxl::read_excel(here("data","PriceOutputTable.xls"), sheet = "Data", col_names = FALSE, col_types = "text") %>%
  dplyr::select(4,5,16) %>%
  slice(462:749)
# assign column names   
colnames(lumbSWD) <- c('year','month','sweden')
# convert "jan, feb, etc" to numeric, create single date from two date columns the convert to R date
lumbSWD <- lumbSWD %>% mutate(date = ymd(paste(year, match(month,month.abb), "1", sep="-"))) %>%
   select(!c(year,month)) 
head(lumbSWD)

# join the U.S. and Swedish lumber tibbles
lumber_both <- merge(lumbUSA,lumbSWD,by="date")

# exchange rate
exchange <- read_csv(here("data", "EXSDUS.csv")) %>%
    mutate(date = mdy(DATE)) %>%
    select(!DATE) 

# add exchange rate to "lumber_both" tibble
lumber <- merge(lumber_both,exchange,by="date")

### Read and Clean ETF Data into a tsibble

# read ICLN data, convert date and volume, and extract last character of "Vol." column
ICLN <- read_csv(here("data","ICLN Historical Data.csv")) %>%
  mutate(date = dmy(Date), volume = as.numeric(str_sub(Vol.,start = 1L,end=-2L)), vol_n = str_sub(Vol., -1)) %>%
  rename(P_ICLN = Price) %>%
  select(P_ICLN,volume,vol_n,date)

# divide volume by 1000 if measured in thousands (i.e., "vol_n = K")
ICLN %>% 
  mutate(V_ICLN = case_when(vol_n == "K" ~ volume/1000
                            ,TRUE ~ volume)) %>%
  select(!volume)

# read PBD data, convert date and volume, and extract last character of "Vol." column
PBD <- read_csv(here("data","PBD Historical Data.csv")) %>%
  mutate(date = dmy(Date), volume = as.numeric(str_sub(Vol.,start = 1L,end=-2L)), vol_n = str_sub(Vol., -1)) %>%
  rename(P_PBD = Price) %>%
  select(P_PBD,volume,vol_n,date)

# divide volume by 1000 if measured in thousands (i.e., "vol_n = K")
PBD %>% 
  mutate(V_PBD = case_when(vol_n == "K" ~ volume/1000
                            ,TRUE ~ volume)) %>%
  select(!volume)

# read S&P500 data, convert date 
SP500 <- read_csv(here("data","S&P 500 Historical Data.csv")) %>%
  mutate(date = dmy(Date), vol_n = str_sub(Vol., -1)) %>%
  rename(P_SP500 = Price) %>%
  select(P_SP500,date)
  
# divide volume by 1000 if measured in thousands (i.e., "vol_n = K")

ICLN %>% 
  mutate(V_ICLN = case_when(vol_n == "K" ~ volume/1000
                                     ,TRUE ~ volume
  )
  )





df %>% { if(apply_filter == TRUE) filter(., condition) else . } %>% 

ICLN <- ICLN %>% mutate(V_ICLN=replace(V_ICLN,vol_n="K",V_ICLN/1000))

#mutate(var = replace(var, var != "Candy", "Not Candy"))

# join data  

ICLN_PBD <- left_join(ICLN, PBD,by="date")
ETF <- left_join(ICLN_PBD,SP500,by="date") %>% 
  relocate(date, .after = last_col()) %>%
  as_tibble(index=date)

# convert volume string to numeric
# extract last character (K or M) from string then delete last character

last <- str_sub(ETF$V_ICLN, -1)
str_sub(ETF$V_ICLN, -1) <- ""

if (str_sub(ETF$V_ICLN, -1) = "K") {
  Expr1 
} else {
  Expr2
}