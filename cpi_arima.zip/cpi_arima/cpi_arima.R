rm(list = ls())

pacman::p_load(tidyverse, lubridate, tsibble, fable, feasts, forecast, here, janitor, gridExtra, fredr)
fredr_set_key("a63c5424469efa8009045b7d02da6a0f")

cpi_raw <- read_csv(here("data", "18100004.csv")) %>% 
  clean_names() %>%
  mutate(date = ym(ref_date)) %>%
  dplyr::select(date,geo,products_and_product_groups,value) %>%
  rename(item = products_and_product_groups, cpi = value)  

cpi <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1978-09-01" & date <= "2022-05-01") %>%
  filter(item == "All-items") %>%
  rename(CPI_can = cpi) %>%
  select(date,CPI_can)

cpi_food <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1978-09-01" & date <= "2022-05-01") %>%
  filter(item == "Food") %>%
  rename(CPI_can_food = cpi) %>%
  select(date,CPI_can_food)

fred_cpi <- fredr(
  series_id = "CPIAUCSL",
  observation_start = as.Date("1978-09-01"),
  observation_end = as.Date("2022-03-01")
) %>% select(date,value) %>% 
  rename(date_cpi = date,CPI_us = value)

fred_cpi_food <- fredr(
  series_id = "CPIUFDNS",
  observation_start = as.Date("1978-09-01"),
  observation_end = as.Date("2022-03-01")
) %>% select(date,value) %>% 
  rename(date_cpi = date,CPI_us_food = value)

fred_cpi_tib <- tibble(fred_cpi, fred_cpi_food[,"CPI_us_food"]) %>% 
  mutate(Month = yearmonth(date_cpi)) %>%
  mutate(Trend = row_number()) %>%
  as_tsibble(index=Month) %>%
  select(Month,CPI_us,CPI_us_food,Trend)
  

cpi_tib <- tibble(cpi, cpi_food[,"CPI_can_food"]) %>% 
  mutate(Month = yearmonth(date)) %>%
  as_tsibble(index=Month) %>%
  select(Month,CPI_can,CPI_can_food)

cpi_can_us <- left_join(fred_cpi_tib,cpi_tib, by = "Month")

saveRDS(cpi_can_us,here("data","cpi_can_us.RDS"))