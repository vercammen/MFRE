# forecast fails if feasts is also loaded
# https://github.com/tidyverts/fable/issues/189

rm(list = ls())

pacman::p_load(tidyverse, lubridate, tsibble, fable, here, janitor, gridExtra, fredr)
options(pillar.sigfig = 5)
 
cpi_data <- readRDS(here("data", "cpi_meat.RDS")) %>%
  mutate(date=yearmonth(date)) %>%
  rename(meat = cpi) %>%
  select(date,meat)

cpi <- cpi_data %>% as_tsibble(index = date) 
tail(cpi)
 
fit_arima <- cpi %>%
  model(ARIMA(meat ~ pdq(2,1,1)))
coef(fit_arima) 
 
for_arima <- fit_arima %>%
  forecast(h=12) %>%
  rename(extra = meat, meat = .mean) %>%
  select(date, meat)

cpi_arima <- dplyr::bind_rows(cpi,for_arima)
tail(cpi_arima, 12)

cpi_qtr <- as_tibble(cpi) %>%
  mutate(quarter = yearquarter(date)) %>%
  group_by(quarter) %>%
  summarise(meat = mean(meat)) %>%
  as_tsibble(index = quarter) 
head(cpi_qtr) 
 
cpi_qtr <- cpi_qtr %>% 
  mutate(difference = difference(meat),
         lagged = lag(meat)) %>%
  slice(-1)
head(cpi_qtr)
 
cpi_qtr <- cpi_qtr %>% 
  mutate(monthly = difference/lagged,
         inflation = (1+monthly)^4-1) %>% 
  select(quarter,inflation)
head(cpi_qtr)
 
fit_arima_qtr <- cpi_qtr %>%
  model(ARIMA(inflation~ pdq(2,0,1)))
coef(fit_arima_qtr) 

for_arima_qtr <- fit_arima_qtr %>%
  forecast(h=8) %>%
  rename(extra = inflation, inflation = .mean) %>%
  select(quarter, inflation)
 
cpi_arima_qtr <- dplyr::bind_rows(cpi_qtr,for_arima_qtr)
tail(cpi_arima_qtr, 4)

# Annual forecast Method 1
# % change between forecasted Sept 21 and actual Sept 20
# % change between forecasted Oct 21 and actual Oct 20
# etc then average
cpi_arima_last <- cpi_arima %>%
  filter_index("2020-09" ~ "2022-09") %>%
  mutate(trail = lag(meat,12),
         monthly = (meat-trail)/trail) %>%
  filter_index("2021-09" ~ "2022-08")
cpi_arima_last

inflation_annual <- mean(cpi_arima_last$monthly)
inflation_annual

## Method 2
cpi_arima_lag <- cpi_arima %>%
  mutate(lag = lag(meat)) %>%
           slice(-1) %>%
  mutate(monthly2 = (meat-lag)/lag) %>%
  filter_index("2021-09" ~ "2022-08")

cpi_arima_lag
inflation_annual2 <- (1+mean(cpi_arima_lag$monthly2))^12-1
inflation_annual2  

## Average Forecasted Inflation
inflation_qtr <- mean(tail(cpi_arima_qtr$inflation,4))
inflation_qtr 
  