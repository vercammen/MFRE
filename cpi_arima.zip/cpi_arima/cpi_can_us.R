rm(list = ls())

pacman::p_load(tidyverse, tsibble, vars, fable, feasts, forecast, here, gridExtra)

cpi_data <-readRDS(here("data","cpi_can_us.RDS"))  %>%
  dplyr::select(-Trend)
  
reg_can_us <- lm(CPI_can ~ CPI_us, cpi_data)
reg_can <- lm(CPI_can_food ~ CPI_can, cpi_data)
reg_us <- lm(CPI_us_food ~ CPI_us, cpi_data)

engle_data <- cpi_data %>% 
  mutate(res_can_us= reg_can_us$resid) %>%
  mutate(res_can = reg_can$resid) %>%
  mutate(res_us = reg_us$resid)

head(engle_data)

engle_can_us <-  ur.df(engle_data$res_can_us, type = "none", selectlags = "AIC")
summary(engle_can_us)@teststat

engle_can <-  ur.df(engle_data$res_can, type = "none", selectlags = "AIC")
summary(engle_can)@teststat

engle_us <-  ur.df(engle_data$res_us, type = "none", selectlags = "AIC")
summary(engle_us)@teststat

source(here("Data","englegranger.R"))
englegranger(2,0,nrow(engle_data)) 

lag_const <- VARselect(cpi_data[,2:5], lag.max = 12, type = "const")[["selection"]]
lag_trend <- VARselect(cpi_data[,2:5], lag.max = 12, type = "trend")[["selection"]]
lag_none <- VARselect(cpi_data[,2:5], lag.max = 12, type = "none")[["selection"]]
cbind(lag_const,lag_trend,lag_none)

LL_const <- logLik(VAR(cpi_data[,2:5],type="const",lag.max=2))
LL_trend <- logLik(VAR(cpi_data[,2:5],type="trend",lag.max=2))
LL_none <- logLik(VAR(cpi_data[,2:5],type="none",lag.max=2))
LL <- data.frame(LL_const,LL_trend,LL_none) 
row.names(LL)[1] <- "Log Likelihood"
LL

jotest <- ca.jo(cpi_data[,2:5], type = "trace", ecdet = "trend", K = 2, spec = "longrun")
cbind(summary(jotest)@teststat, summary(jotest)@cval) 

cpi_data <- cpi_data %>% 
  mutate(D.CPI_can = difference(CPI_can)) %>%
  mutate(D.CPI_can_food = difference(CPI_can_food)) %>%
  mutate(D.CPI_us = difference(CPI_us)) %>%
  mutate(D.CPI_us_food = difference(CPI_us_food))

regA <- lm(D.CPI_can_food ~ D.CPI_us_food+D.CPI_us+D.CPI_can,cpi_data[-1,])
summary(regA)  

model1 <- VAR(cpi_data[-1,c("D.CPI_can_food","D.CPI_can","D.CPI_us","D.CPI_us_food")], p = 3, type = c("const"))
coef(model1)

#write_csv(cpi_data,here("data","cpi_can_us.csv"))