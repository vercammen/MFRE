rm(list = ls())
pacman::p_load(tidyverse, lubridate,  here, janitor)

# read in raw cpi data from global file (downloaded from https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1810000403)
cpi_raw <- read_csv(here("data", "18100004.csv")) %>% 
  clean_names() %>%
  mutate(date = ym(ref_date)) %>%
 dplyr::select(date,geo,products_and_product_groups,value) %>%
  rename(item = products_and_product_groups, cpi = value)  

# filter date and category
# start = September, 1978
cpi_meat <- cpi_raw %>% 
  filter(geo == "Canada") %>%
  filter(date >= "1978-09-01" & date <= "2021-08-01") %>%
  filter(item == "Meat")
  

# save data as RDS file
saveRDS(cpi_meat, here("data", "cpi_meat.RDS")) 