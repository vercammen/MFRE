rm(list = ls())

pacman::p_load(tidyverse, janitor, readxl,here, lubridate, tsibble, vars)

# read and clean crude oil weekly futures prices

crude_price <- read_excel(here("data", "crude_price.xlsx"), sheet = "Data 1", skip = 2, na = "..") %>%
  clean_names()

crude_price <- crude_price %>%
  rename(crude_price = 2) %>%
  mutate(date = as.Date(date),
         week = yearweek(date)) %>%
  dplyr::select(week,crude_price) %>%
  as_tsibble(index = week) %>%
  filter_index("1984 w1" ~ .)

# read and clean crude oil weekly stocks

crude_stock <- read_excel(here("data", "crude_stock.xlsx"), sheet = "Data 1", skip = 2, na = "..") %>%
  clean_names()

crude_stock <- crude_stock %>%
  rename(crude_stock = 2) %>%
  mutate(date = as.Date(date),
         week = yearweek(date)) %>%
  dplyr::select(week,crude_stock) %>%
  as_tsibble(index = week) %>%
  filter_index("1984 w1" ~ .)

# read and clean ethanol stocks
ethanol_stock <- read_excel(here("data", "ethanol_stock.xlsx"), sheet = "Data 1", skip = 2, na = "..") %>%
  clean_names()

ethanol_stock <- ethanol_stock %>%
  rename(ethanol_stock = 2) %>%
  mutate(date = as.Date(date),
         week = yearweek(date)) %>%
  dplyr::select(week,ethanol_stock) %>%
  as_tsibble(index = week)  

# read and clean ethanol price
ethanol_price <- read_excel(here("data", "ethanol_price.xlsx"), sheet = "Ethanol Futures Historical Data") %>%
  rename(ethanol_price = Price) %>%
  mutate(date = as.Date(Date),
         week = yearweek(date)) %>%
  dplyr::select(week,ethanol_price)  
  
# combine crude oil prices and inventory
crude <- inner_join(crude_price,crude_stock,join=week)

# group crude and ethanol prices and inventory
crude_price_short <- crude_price %>%
  filter_index("1984 w1" ~ .)
crude_stock_short <- crude_stock %>%
  filter_index("1984 w1" ~ .)
  
data_level <- crude_price_short %>% inner_join(crude_stock,join=week) %>%
  inner_join(ethanol_price,join=week) %>%
  inner_join(ethanol_stock,join=week)

# create first difference data set using data_level
data <- data_level %>%
  mutate(p_oil = difference(crude_price),
         s_oil = difference(crude_stock),
         p_ethan = difference(ethanol_price),
         s_ethan = difference(ethanol_stock)) %>%
  slice(-1) %>%
  dplyr::select(week,p_oil,s_oil,p_ethan,s_ethan)

# determine optimal lags for VAR analysis (subtract 1 because using FD)
VARselect(data[,2:5],lag.max=10,type="const")

varmod <- VAR(data[,2:5], p = 1, type = "const")
coef(varmod)
 