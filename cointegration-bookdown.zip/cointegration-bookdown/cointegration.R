# https://mran.microsoft.com/snapshot/2020-04-15/web/packages/feasts/feasts.pdf

rm(list = ls())
graphics.off()


pacman::p_load(tidyverse, here, vars, tsibble, feasts, tsibbledata, forecast)  

## READ DATA

vegoil <- readRDS(here("data", "vegoils.RDS"))
head(vegoil)
biofuel <- readRDS(here("data", "biofuel.RDS"))
head(biofuel)
ETF <- readRDS(here("data", "ETF.RDS"))
head(ETF)   

# create logged vegoil variables and select these for further analysis
lnveg <- vegoil %>% mutate(lnpo = log(palm_oil),lnso=log(soybean_oil), lnro = log(rapeseed_oil))  %>%
  dplyr::select(month,lnpo,lnso,lnro)

# create logged biofuel variables and select these for further analysis
lnfuel <- biofuel %>% mutate(lnbio = log(biodiesel),lnsoy=log(soyoil), lndiesel=log(diesel),lncrude=log(crude))  %>%
  dplyr::select(lnbio,lnsoy,lndiesel,lncrude)

# Create first differences and lagged first differences for logged vegoil
lnveg <- lnveg %>% mutate(D.lnpo=difference(lnpo, 1,1),D.lnso=difference(lnso, 1,1),D.lnro=difference(lnro, 1,1)) 
lnveg <- lnveg %>% mutate(DL.lnpo=dplyr::lag(D.lnpo, 1),DL.lnso=dplyr::lag(D.lnso, 1),DL.lnro=dplyr::lag(D.lnro, 1))
head(lnveg)

# Create first differences and lagged first differences for logged biofuel
lnfuel <- lnfuel %>% mutate(D.lnbio=difference(lnbio, 1,1),D.lnsoy=difference(lnsoy, 1,1),D.lndiesel=difference(lndiesel, 1,1),D.lncrude=difference(lncrude, 1,1)) 
lnfuel <- lnfuel %>% mutate(DL.lnbio=dplyr::lag(D.lnbio, 1),DL.lnsoy=dplyr::lag(D.lnsoy, 1))
head(lnfuel)

# stack three data series for plotting

stack_po <- as_tibble(lnveg)  %>% 
  dplyr::select(month,lnpo) %>%
  rename(log_price = lnpo) %>%
  mutate(Oil = "Palm")

stack_so <- as_tibble(lnveg)  %>% 
  dplyr::select(month,lnso) %>%
  rename(log_price = lnso) %>%
  mutate(Oil = "Soybean")

stack_ro <- as_tibble(lnveg)  %>% 
  dplyr::select(month,lnro) %>%
  rename(log_price = lnro) %>%
  mutate(Oil = "Rapeseed")

stack <- bind_rows(stack_po,stack_so, stack_ro)

# plot the stacked data

ggplot(stack,aes(y = log_price,x = month,color = Oil)) + 
  geom_line() +
  ggtitle("Log of Monthly Average Prices of Three Vegetable Oils")

# plot log of biodiesel price
# lnp %>% autoplot(lnbio) +
#  labs(title = "Log of Monthly Biodiesel Price",#
#       subtitle = "April 2007 to Feb 2022",
#       y = "$/gallon")

# generate autocorrelation and partial autocorrelation plots
lnveg %>% ACF(lnso) %>% autoplot()
 
# ADF test for lnveg

adfpo <- list(
  trend = ur.df(lnveg$lnpo, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$lnpo, type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$lnpo, type = "none", selectlags = "AIC")
)

adfso <- list(
  trend = ur.df(lnveg$lnso, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$lnso, type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$lnso, type = "none", selectlags = "AIC")
)

adfro <- list(
  trend = ur.df(lnveg$lnro, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$lnro, type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$lnro, type = "none", selectlags = "AIC")
)

# generate ADF test statistics for veg_oil

potrend <- summary(adfpo$trend)@teststat
podrift <- summary(adfpo$drift)@teststat
ponone <- summary(adfpo$none)@teststat
adf_po <- cbind(potrend,podrift,ponone)
 
sotrend <- summary(adfso$trend)@teststat
sodrift <- summary(adfso$drift)@teststat
sonone <- summary(adfso$none)@teststat
adf_so <- cbind(sotrend,sodrift,sonone)

rotrend <- summary(adfro$trend)@teststat
rodrift <- summary(adfro$drift)@teststat
ronone <- summary(adfro$none)@teststat
adf_ro <- cbind(rotrend,rodrift,ronone)

adf_veg <- rbind(adf_po,adf_so,adf_ro)
rownames(adf_veg)  <- c("Palm Oil", "Soybean Oil", "Rapeseed Oil")
adf_veg

# ADF critical values for ln palm oil (the same for all three veggie oils)

rbind(adfpo$trend@cval,adfpo$drift@cval)

# ADF test for lnfuel.

adfbio <- list(
  trend = ur.df(lnfuel$lnbio, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$lnbio, type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$lnbio, type = "none", selectlags = "AIC")
)

adfsoy <- list(
  trend = ur.df(lnfuel$lnsoy, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$lnsoy, type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$lnsoy, type = "none", selectlags = "AIC")
)

adfdiesel <- list(
  trend = ur.df(lnfuel$lndiesel, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$lndiesel, type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$lndiesel, type = "none", selectlags = "AIC")
)

adfcrude <- list(
  trend = ur.df(lnfuel$lncrude, type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$lncrude, type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$lncrude, type = "none", selectlags = "AIC")
)

# generate ADF test statistics for lnfuel

biotrend <- summary(adfbio$trend)@teststat
biodrift <- summary(adfbio$drift)@teststat
bionone <- summary(adfbio$none)@teststat
adf_bio <- cbind(biotrend,biodrift,bionone)

soytrend <- summary(adfsoy$trend)@teststat
soydrift <- summary(adfsoy$drift)@teststat
soynone <- summary(adfsoy$none)@teststat
adf_soy <- cbind(soytrend,soydrift,soynone)

dieseltrend <- summary(adfdiesel$trend)@teststat
dieseldrift <- summary(adfdiesel$drift)@teststat
dieselnone <- summary(adfdiesel$none)@teststat
adf_diesel <- cbind(dieseltrend,dieseldrift,dieselnone)

crudetrend <- summary(adfcrude$trend)@teststat
crudedrift <- summary(adfcrude$drift)@teststat
crudenone <- summary(adfcrude$none)@teststat
adf_crude <- cbind(crudetrend,crudedrift,crudenone)

adf_fuel <- rbind(adf_bio,adf_soy,adf_diesel, adf_crude)
rownames(adf_fuel)  <- c("Biodiesel", "Soybean Oil", "Diesel", "Crude Oil")
adf_fuel


# ADF critical values for ln biodiesel (the same for all four data series)

adfbio$trend@cval

# REPEAT BUT WITH FIRST DIFFERENCES

# ADF tests for DIFF lnveg

D.adfpo <- list(
  trend = ur.df(lnveg$D.lnpo[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$D.lnpo[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$D.lnpo[-1], type = "none", selectlags = "AIC")
)

D.adfso <- list(
  trend = ur.df(lnveg$D.lnso[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$D.lnso[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$D.lnso[-1], type = "none", selectlags = "AIC")
)

D.adfro <- list(
  trend = ur.df(lnveg$D.lnro[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnveg$D.lnro[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnveg$D.lnro[-1], type = "none", selectlags = "AIC")
)


# generate ADF test statistics for DIFF veg_oil

D.potrend <- summary(D.adfpo$trend)@teststat
D.podrift <- summary(D.adfpo$drift)@teststat
D.ponone <- summary(D.adfpo$none)@teststat
D.adf_po <- cbind(D.potrend,D.podrift,D.ponone)

D.sotrend <- summary(D.adfso$trend)@teststat
D.sodrift <- summary(D.adfso$drift)@teststat
D.sonone <- summary(D.adfso$none)@teststat
D.adf_so <- cbind(D.sotrend,D.sodrift,D.sonone)

D.rotrend <- summary(D.adfro$trend)@teststat
D.rodrift <- summary(D.adfro$drift)@teststat
D.ronone <- summary(D.adfro$none)@teststat
D.adf_ro <- cbind(D.rotrend,D.rodrift,D.ronone)

D.adf_veg <- rbind(D.adf_po,D.adf_so,D.adf_ro)
rownames(D.adf_veg)  <- c("Diff Palm Oil", "Diff Soybean Oil", "Diff Rapeseed Oil")
D.adf_veg


# ADF critical values for DIFF ln palm oil (the same for all three veggie oils)

D.adfpo$trend@cval


# ADF test for lnfuel.

D.adfbio <- list(
  trend = ur.df(lnfuel$D.lnbio[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$D.lnbio[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$D.lnbio[-1], type = "none", selectlags = "AIC")
)

D.adfsoy <- list(
  trend = ur.df(lnfuel$D.lnsoy[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$D.lnsoy[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$D.lnsoy[-1], type = "none", selectlags = "AIC")
)

D.adfdiesel <- list(
  trend = ur.df(lnfuel$D.lndiesel[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$D.lndiesel[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$D.lndiesel[-1], type = "none", selectlags = "AIC")
)

D.adfcrude <- list(
  trend = ur.df(lnfuel$D.lncrude[-1], type = "trend", selectlags = "AIC"),
  drift = ur.df(lnfuel$D.lncrude[-1], type = "drift", selectlags = "AIC"),
  none = ur.df(lnfuel$D.lncrude[-1], type = "none", selectlags = "AIC")
)

# generate ADF test statistics for lnfuel

D.biotrend <- summary(D.adfbio$trend)@teststat
D.biodrift <- summary(D.adfbio$drift)@teststat
D.bionone <- summary(D.adfbio$none)@teststat
D.adf_bio <- cbind(D.biotrend,D.biodrift,D.bionone)

D.soytrend <- summary(D.adfsoy$trend)@teststat
D.soydrift <- summary(D.adfsoy$drift)@teststat
D.soynone <- summary(D.adfsoy$none)@teststat
D.adf_soy <- cbind(D.soytrend,D.soydrift,D.soynone)

D.dieseltrend <- summary(D.adfdiesel$trend)@teststat
D.dieseldrift <- summary(D.adfdiesel$drift)@teststat
D.dieselnone <- summary(D.adfdiesel$none)@teststat
D.adf_diesel <- cbind(D.dieseltrend,dieseldrift,dieselnone)

D.crudetrend <- summary(D.adfcrude$trend)@teststat
D.crudedrift <- summary(D.adfcrude$drift)@teststat
D.crudenone <- summary(D.adfcrude$none)@teststat
D.adf_crude <- cbind(D.crudetrend,D.crudedrift,D.crudenone)

D.adf_fuel <- rbind(D.adf_bio,D.adf_soy,D.adf_diesel, D.adf_crude)
rownames(adf_fuel)  <- c("DIFF Biodiesel", "DIFF Soybean Oil", "DIFF Diesel", "DIFF Crude Oil")
D.adf_fuel


# ADF critical values for DIFF ln biodiesel (the same for all four data series)

D.adfbio$trend@cval

# Johansen Test for Cointegration
# Page 10 of https://cran.r-project.org/web/packages/urca/urca.pdf

# https://www.r-bloggers.com/2021/12/vector-error-correction-model-vecm-using-r/
# f r > 0, apply the cajorls() function to the ca.jo() output to get estimated parameters of the VECM model in differences

# https://rdrr.io/cran/vars/man/logLik.html

# Optimal lags for oilseed VAR
#https://rdrr.io/github/tidyverts/fable/man/VAR.html


lag_const <- VARselect(lnveg[,2:4], lag.max = 10, type = "const")[["selection"]]
lag_trend <- VARselect(lnveg[,2:4], lag.max = 10, type = "trend")[["selection"]]
lag_both <- VARselect(lnveg[,2:4], lag.max = 10, type = "both")[["selection"]]
lag_none <- VARselect(lnveg[,2:4], lag.max = 10, type = "none")[["selection"]]
cbind(lag_const,lag_trend,lag_both,lag_none)


jotest <- ca.jo(lnveg[,2:4], type = "trace", ecdet = "none", K = 2)

cbind(summary(jotest)@teststat, summary(jotest)@cval)


test <- jotest@cval
cbind(summary(jotest)@teststat,test)

test2 <- VAR(lnveg[,2:4])
Acoef(test2)

