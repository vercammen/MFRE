englegranger <- function(var, trend, n){
   
  Confidence <- c("1%", "5%", "10%")
  Size <- c(nrow(lnfuel),nrow(lnfuel),nrow(lnfuel))
   NoTrend_TwoVar <- c(-3.9001-10.534/n-30.03/n^2,-3.3377-5.967/n-8.98/n^2,-3.0462-4.069/n-5.73/n^2)
   Trend_TwoVar <- c(-4.326-15.531/n-34.03/n^2,-3.7809-9.421/n-15.06/n^2,-3.4959-7.203/n-4.01/n^2)
   NoTrend_ThreeVar <- c(-4.2981-13.79/n-46.37/n^2,-3.7429-8.352/n-13.41/n^2,-3.4518-6.241/n-2.19/n^2)
   Trend_ThreeVar <- c(-4.6676-18.492/n-18.492/n^2,-4.1193-12.024/n-12.024/n^2,-3.8344-9.188/n-9.188/n^2)
   critval <- data.frame(Confidence,Size,NoTrend_TwoVar,Trend_TwoVar,NoTrend_ThreeVar,Trend_ThreeVar)
   
    if (var == 2 & trend == 0){
      critval[c('Confidence','Size', 'NoTrend_TwoVar')]
  } else if (var == 2 & trend == 1){
      critval[c('Confidence','Size', 'Trend_TwoVar')]
  } else if (var == 3 & trend == 0){
      critval[c('Confidence','Size', 'NoTrend_ThreeVar')]
  } else if (var == 3 & trend == 1){
      critval[c('Confidence','Size', 'Trend_ThreeVar')]
  } else {
    print('Beyond the scope of this analysis')
  }
}