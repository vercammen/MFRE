
library(raster)
library(tmap)
library(sf)
library(ggplot2)
library(data.table)
library(rmarkdown)
library(readxl)
library(foreign)

setwd("C:/Users/vercamme/Dropbox/Administration/FRE Hire/Salemi/Data")

floodRisk = raster("flood risk.tif")
districts = getData('GADM', country = 'RWA', level = 2)

tm_shape(floodRisk) + 
  tm_raster(palette = "-RdBu", title = "Flood risk", style = "cat") +
  tm_shape(districts) + tm_borders(col = "black") +
  tm_layout(legend.outside = T, frame = F)