#Mapping high resolution population data for Canada


library(sf)
library(ggplot2)
library(raster)
library(tmap)

#Colette's working directory
#setwd("G:/My Drive/Canada")
setwd("C:/Users/vercamme/Dropbox/Teach/Geo-Spatial/Data")


#Cleaned sf object with population counts per grid-cell
load("can_pop.Rda")

#Canada country boundary
Canada = getData("GADM", country = "CAN", level = 0)

#Dropping polygon borders in ggplot - this is very non-intuitive, but if you add "color = NA" 
#as below, the borders are not displayed, It's weird code like this that makes me choose tmap
#over ggplot for mapping (ggplot is great for bar or line charts, scatter plots, etc.)

ggplot() +
  geom_sf(data = can_pop, mapping = aes(fill = TOT_POP2A), color = NA) + coord_sf() +
  ggtitle("Gridded population of Canada") 

#Save the map
ggsave("Map no borders using ggplot.jpeg")

#It's not a pretty map: even when supressing the borders, we see very little variation, because
#grid-cells with a population of zero make up a majority share of the observations.


#Using tmap, we can define the breaks in the continous variable being mapped. Here I define
#breaks at intervals of 1,000 up until 5,000, beyond which the category is "5000 or more".
  map2 = tm_shape(can_pop) + 
   tm_fill("TOT_POP2A", 
          palette = "Reds", 
          title = "Pop. count", 
          breaks = c(0, 1000, 2000, 3000, 4000, 5000, Inf),
          textNA = "Water",
          colorNA = "cadetblue3") + 
  tm_shape(Canada) + 
   tm_borders(col = "grey") +
  tm_layout(legend.outside = T, frame = F, main.title = "Gridded population of Canada")

  tmap_save(map2, "Map with defined breaks.jpeg")


  
  
#Because we can manipulate sf objects like dataframes in R, we can also define a categorical
#variable of population groups as defined by the researcher and then map this categorical
#information. 
  
can_pop$popGrps = ifelse(can_pop$TOT_POP2A==0, "Zero", 
                  ifelse(can_pop$TOT_POP2A>0 & can_pop$TOT_POP2A<=1000, "1 to 1,000",
                  ifelse(can_pop$TOT_POP2A>1000, "More than 1,000", NA)))

map3 = tm_shape(can_pop) + 
  tm_fill("popGrps", 
          palette = "-Reds", 
          title = "Pop. count",
          textNA = "Water",
          colorNA = "cadetblue3") + 
  tm_shape(Canada) + 
  tm_borders(col = "grey") +
  tm_layout(legend.outside = T, frame = F, main.title = "Gridded population of Canada")

map3 
 
tmap_save(map3, "Map with new categorical variable.jpeg")