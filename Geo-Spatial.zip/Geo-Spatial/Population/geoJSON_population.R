library(geojsonsf)
library(sf)
library(dplyr) 
library(ggplot2)

setwd("C:/Users/vercamme/Dropbox/Teach/Geo-Spatial/Data")

sfdb <- geojson_sf("https://agriculture.canada.ca/atlas/data_donnees/cul/griddedPopulationCanada10km/geoJSON/griddedPopulationCanada10km_2016.geojson")
save(sfdb,file="sfdb.Rda")

sfdb_mini <- sfdb[-(1:3)]
sfdb_mini <- sfdb_mini[-(2:13)]

save(sfdb_mini,file="can_pop.Rda")


# https://ggplot2.tidyverse.org/reference/ggsf.html



