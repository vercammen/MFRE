# https://geocompr.robinlovelace.net/spatial-class.html
# Geometric VECTOR (e.g., lines and polygons) 
library(sf)
library(terra)
library(spData)
# show the four objects in "world"
class(world)
# shown the column names in world ("geom" column is the spatial data)
names(world)
# world$geom is a 'list column' that contains all the coordinates of the country polygons.
plot(world)
# plot statistics for life expectancy (geom data is automatically included)
plot(world["pop"])
summary(world["lifeExp"])
# subset
world_mini = world[1:2, 1:3]
world_mini

# group all Asian countries together
world_asia = world[world$continent == "Asia", ]
asia = st_union(world_asia)

#plot the Asian continent over a map of the world (i.e., layers). 
plot(world["pop"], reset = FALSE)
plot(asia, add = TRUE, col = "red")

#show country populations as circles of varying sizes
#uses the function st_centroid() to convert one geometry type (polygons) to another (points) 
plot(world["continent"], reset = FALSE)
cex = sqrt(world$pop) / 10000
world_cents = st_centroid(world, of_largest = TRUE)
plot(st_geometry(world_cents), add = TRUE, cex = cex)
