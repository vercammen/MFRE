#https://gis.stackexchange.com/questions/214062/create-a-shapefile-from-dataframe-in-r-keeping-attribute-table

library(maptools)
library(rgdal)
library(sp)
library(ggplot2)

#data
site <- c("a","b","c","d")
prop_c <- c(0.88,0.48,0.15,0.47)
prop_b <- c(0.17,0.18,0.09,0.08)
minus_c <- 1-prop_c
minus_b <- 1-prop_b
lat <- c(44.22,38.38,33.35,49.48)
long <- c(-124.45, -132.70, -108.40, -130.05)
#lat <- c(44.22,38.38,33.35,43.48)
#long <- c(-124.45, -123.70, -124.40, -124.05)
MyData <- cbind.data.frame(site, prop_c, prop_b, minus_c, minus_b, lat, long)

WGScoor<-  MyData
coordinates(WGScoor)=~long+lat
proj4string(WGScoor)<- CRS("+proj=longlat +datum=WGS84")

class(WGScoor)
sf_data <- dat <- as(WGScoor, "sf")

ggplot() +
  geom_sf(data = sf_data) +
  ggtitle("Map of Plot Locations")

# https://gis.stackexchange.com/questions/403977/sf-create-polygon-from-minimum-x-and-y-coordinates
#lon = c(756065.70, 757428.78)
#lat = c(4074435.19,4075144.12)
lon = c(-10500, -13500)
lat = c(3200, 5000)
Poly_Coord_df = data.frame(lon, lat)
pol = st_polygon(
  list(
    cbind(
      Poly_Coord_df$lon[c(1,2,2,1,1)], 
      Poly_Coord_df$lat[c(1,1,2,2,1)])
  )
)

polc = st_sfc(pol, crs=32611)

ggplot() +
  geom_sf(data = polc) +
  geom_sf(data = sf_data) +
  ggtitle("Map of Plot Locations")

# convert .shp file to sf
fname <- system.file("shape/nc.shp", package="sf")
nc <- st_read(fname)
names(nc)
nc$geometry
plot(nc)
  